import re
import numpy as np
import pandas as pd

# =========================================================
# 1) 推断引擎：支持 rank / percent + 后验预测检验（不筛选样本）
# =========================================================
class DWTSInferenceEngine:
    def __init__(self, judges_scores, contestant_names, method="rank", seed=0):
        self.judges_scores = np.array(judges_scores, dtype=float)
        self.contestant_names = list(contestant_names)
        self.method = method
        self.rng = np.random.default_rng(seed)

        if len(self.judges_scores) != len(self.contestant_names):
            raise ValueError("judges_scores length must match contestant_names length.")
        if np.any(~np.isfinite(self.judges_scores)):
            raise ValueError("judges_scores contains NaN/inf; please filter roster before inference.")
        self.n = len(self.contestant_names)

    @staticmethod
    def _rank_min_desc(values: np.ndarray) -> np.ndarray:
        """
        返回“分高排名小(1=best)”的 min-rank（并列取最小名次）。
        """
        v = np.asarray(values, dtype=float)
        order = np.argsort(-v, kind="mergesort")
        ranks = np.empty_like(order, dtype=float)
        ranks[order] = np.arange(1, len(v) + 1)

        sorted_v = v[order]
        start = 0
        while start < len(v):
            end = start + 1
            while end < len(v) and sorted_v[end] == sorted_v[start]:
                end += 1
            min_rank = start + 1
            ranks[order[start:end]] = min_rank
            start = end
        return ranks

    def _judge_metric(self):
        if self.method == "rank":
            return self._rank_min_desc(self.judges_scores)  # 1=best
        elif self.method == "percent":
            total_j = float(np.sum(self.judges_scores))
            if total_j <= 0:
                raise ValueError("Total judges score must be positive for percent method.")
            return self.judges_scores / total_j
        else:
            raise ValueError("method must be 'rank' or 'percent'")

    # --------------------------
    # (A) 原 1.3：淘汰约束推断
    # --------------------------
    def run_simulation_elimination(self, eliminated_name: str, n_simulations=100000):
        """
        条件推断（淘汰约束）：筛选出“能导致指定淘汰者出局”的 fan vote samples
        返回：
        - mean_votes, std_votes
        - feasible_rate, num_valid
        """
        if eliminated_name not in self.contestant_names:
            raise ValueError(f"Eliminated contestant '{eliminated_name}' not in roster.")
        elim_idx = self.contestant_names.index(eliminated_name)

        j_metric = self._judge_metric()
        samples = self.rng.dirichlet(np.ones(self.n), size=n_simulations)

        if self.method == "rank":
            valid_mask = np.zeros(n_simulations, dtype=bool)
            for s in range(n_simulations):
                f_metric = self._rank_min_desc(samples[s])
                combined = j_metric + f_metric  # 越小越好
                worst = np.max(combined)        # 最差为最大
                worst_idx = np.where(combined == worst)[0]
                valid_mask[s] = (elim_idx in worst_idx)
        else:
            combined = j_metric[None, :] + samples  # 越大越好
            worst = np.min(combined, axis=1)        # 最差为最小
            valid_mask = (combined[:, elim_idx] == worst)

        valid = samples[valid_mask]
        num_valid = int(valid.shape[0])
        feasible_rate = num_valid / float(n_simulations)

        if num_valid == 0:
            return None, None, feasible_rate, 0

        return np.mean(valid, axis=0), np.std(valid, axis=0), feasible_rate, num_valid

    # --------------------------
    # (B) 原 1.3：finals 排名约束推断
    # --------------------------
    def run_simulation_final_ranking(self, order_best_to_worst, n_simulations=100000):
        """
        Finals 周（排名约束）：
        给定 order_best_to_worst（索引列表，按最终名次从好到差排列），
        筛选使得“合并得分排序”与该顺序一致的 fan vote samples。

        rank 规则：combined = judge_rank + fan_rank，越小越好，所以要求：
          combined[best] <= combined[next] <= ... <= combined[worst]

        percent 规则：combined = judge_percent + fan_percent，越大越好，所以要求：
          combined[best] >= combined[next] >= ... >= combined[worst]
        """
        j_metric = self._judge_metric()
        samples = self.rng.dirichlet(np.ones(self.n), size=n_simulations)

        valid_mask = np.zeros(n_simulations, dtype=bool)

        if self.method == "rank":
            for s in range(n_simulations):
                f_metric = self._rank_min_desc(samples[s])
                combined = j_metric + f_metric  # 越小越好
                ok = True
                for a, b in zip(order_best_to_worst[:-1], order_best_to_worst[1:]):
                    if combined[a] > combined[b]:  # 违反“好<=差”
                        ok = False
                        break
                valid_mask[s] = ok
        else:
            combined_all = j_metric[None, :] + samples  # 越大越好
            for s in range(n_simulations):
                combined = combined_all[s]
                ok = True
                for a, b in zip(order_best_to_worst[:-1], order_best_to_worst[1:]):
                    if combined[a] < combined[b]:  # 违反“好>=差”
                        ok = False
                        break
                valid_mask[s] = ok

        valid = samples[valid_mask]
        num_valid = int(valid.shape[0])
        feasible_rate = num_valid / float(n_simulations)

        if num_valid == 0:
            return None, None, feasible_rate, 0

        return np.mean(valid, axis=0), np.std(valid, axis=0), feasible_rate, num_valid

    # --------------------------
    # (C) 新增：1.2 的后验/先验预测检验（不筛选样本）
    # --------------------------
    def posterior_predictive_elim_probs(self, eliminated_name: str, n_simulations=50000, tie_mode="split"):
        """
        不筛选样本的一致性检验：在 Dirichlet(1) 先验下，模型“预测淘汰”的概率分布。
        做法：
          - 对每个 Monte Carlo sample 都按规则预测“谁会被淘汰”
          - 统计每位选手被淘汰的频率，得到 p_elim 向量

        返回：
          p_elim: shape (n,) 每位选手被淘汰的概率（和为1）
          rank_all: shape (n,) 每位选手在 p_elim 中从大到小的 min-rank（1=最可能被淘汰）
          p_elim_true: 指定 eliminated_name 的淘汰概率
          rank_true: 指定 eliminated_name 的淘汰概率排名（同 rank_all[elim_idx]）

        tie_mode:
          - "split": 并列最差时，概率在并列者之间平均分摊（推荐）
          - "first": 并列最差时，只记第一个（不推荐）
        """
        if eliminated_name not in self.contestant_names:
            raise ValueError(f"Eliminated contestant '{eliminated_name}' not in roster.")
        elim_idx = self.contestant_names.index(eliminated_name)

        j_metric = self._judge_metric()
        samples = self.rng.dirichlet(np.ones(self.n), size=n_simulations)  # (S, n)

        elim_counts = np.zeros(self.n, dtype=float)

        if self.method == "rank":
            # rank: combined 越大越差（rank 数字越大越差）
            for s in range(n_simulations):
                f_metric = self._rank_min_desc(samples[s])  # 1=best
                combined = j_metric + f_metric
                worst = np.max(combined)
                worst_idx = np.where(combined == worst)[0]

                if tie_mode == "split":
                    elim_counts[worst_idx] += 1.0 / len(worst_idx)
                elif tie_mode == "first":
                    elim_counts[worst_idx[0]] += 1.0
                else:
                    raise ValueError("tie_mode must be 'split' or 'first'")
        else:
            # percent: combined 越小越差（最低 combined 淘汰）
            combined = j_metric[None, :] + samples
            worst = np.min(combined, axis=1)
            for s in range(n_simulations):
                worst_idx = np.where(combined[s] == worst[s])[0]
                if tie_mode == "split":
                    elim_counts[worst_idx] += 1.0 / len(worst_idx)
                elif tie_mode == "first":
                    elim_counts[worst_idx[0]] += 1.0
                else:
                    raise ValueError("tie_mode must be 'split' or 'first'")

        p_elim = elim_counts / np.sum(elim_counts)

        # 1=最可能淘汰（概率最大）；并列取最小名次
        rank_all = self._rank_min_desc(p_elim).astype(int)

        p_elim_true = float(p_elim[elim_idx])
        rank_true = int(rank_all[elim_idx])

        return p_elim, rank_all, p_elim_true, rank_true



# =========================================================
# 2) 解析 results 字段：抽取淘汰周数（鲁棒版）
# =========================================================
def parse_elim_week(results_str: str):
    if not isinstance(results_str, str) or not results_str.strip():
        return np.nan

    s = results_str.strip()
    patterns = [
        r"Eliminated\s+Week\s+(\d+)",
        r"Eliminated.*?Week\s*(\d+)",
        r"Week\s*(\d+).*?Eliminated",
    ]
    for pat in patterns:
        m = re.search(pat, s, flags=re.IGNORECASE)
        if m:
            return int(m.group(1))
    return np.nan


# =========================================================
# 3) 工具函数：获取某 season 某 week 的 judge_cols
# =========================================================
def get_judge_cols(season_df: pd.DataFrame, week: int):
    return [c for c in season_df.columns if c.startswith(f"week{week}_judge") and c.endswith("_score")]


# =========================================================
# 4) 获取当周 roster & judge_total（只返回 judge_total>0 的活跃选手）
# =========================================================
def get_week_roster_and_scores(season_df: pd.DataFrame, week: int):
    judge_cols = get_judge_cols(season_df, week)
    if not judge_cols:
        return [], [], judge_cols

    tmp = season_df[["celebrity_name"] + judge_cols].copy()
    participated_mask = tmp[judge_cols].notna().any(axis=1)  # 0 也算“有记录”
    tmp = tmp.loc[participated_mask].copy()

    if tmp.empty:
        return [], [], judge_cols

    tmp["judge_total"] = tmp[judge_cols].sum(axis=1, skipna=True)

    # 只保留仍在比赛中的：judge_total > 0
    tmp = tmp[np.isfinite(tmp["judge_total"]) & (tmp["judge_total"] > 0)].copy()

    names = tmp["celebrity_name"].tolist()
    scores = tmp["judge_total"].astype(float).tolist()
    return names, scores, judge_cols


# =========================================================
# 5) 获取“包含 0 在内”的当周 judge_total（用于推断隐性淘汰）
# =========================================================
def get_week_totals_including_zero(season_df: pd.DataFrame, week: int):
    judge_cols = get_judge_cols(season_df, week)
    if not judge_cols:
        return pd.Series(dtype=float)

    tmp = season_df[["celebrity_name"] + judge_cols].copy()
    participated_mask = tmp[judge_cols].notna().any(axis=1)
    tmp = tmp.loc[participated_mask].copy()
    if tmp.empty:
        return pd.Series(dtype=float)

    tmp["judge_total"] = tmp[judge_cols].sum(axis=1, skipna=True).astype(float)
    return tmp.set_index("celebrity_name")["judge_total"]


# =========================================================
# 6) 无淘汰周补全：若 week 没淘汰记录，则检查 week+1
#    若某人本周>0 且下周==0，则认为他本周被淘汰
# =========================================================
def infer_elims_by_nextweek_zero(season_df: pd.DataFrame, week: int, max_week: int):
    if week >= max_week:
        return []

    tot_w = get_week_totals_including_zero(season_df, week)
    tot_next = get_week_totals_including_zero(season_df, week + 1)
    if tot_w.empty or tot_next.empty:
        return []

    idx = tot_w.index.intersection(tot_next.index)
    if len(idx) == 0:
        return []

    w = tot_w.loc[idx]
    n = tot_next.loc[idx]
    return idx[(w > 0) & (n == 0)].tolist()


# =========================================================
# 7) Finals 机制：定位 finals_week + 用 placement 构造“最终名次排序约束”
# =========================================================
def find_finals_week(season_df: pd.DataFrame, max_week: int):
    """
    从后往前找最后一个“活跃参赛人数>=2”的 week 作为 finals_week。
    """
    for w in range(max_week, 0, -1):
        roster_names, _, _ = get_week_roster_and_scores(season_df, w)
        if len(roster_names) >= 2:
            return w
    return None


def infer_finals_order_by_placement(season_df: pd.DataFrame, finals_week: int):
    """
    finals_week 当周活跃选手 roster（judge_total>0），按 placement(1最好) 排序，返回：
      roster_names, roster_scores, order_best_to_worst（索引序）, order_names
    """
    roster_names, roster_scores, _ = get_week_roster_and_scores(season_df, finals_week)
    if len(roster_names) < 2:
        return None

    sub = season_df[season_df["celebrity_name"].isin(roster_names)][["celebrity_name", "placement"]].copy()
    sub["placement_num"] = pd.to_numeric(sub["placement"], errors="coerce")
    if sub["placement_num"].isna().any():
        return None

    sub = sub.sort_values("placement_num", ascending=True)
    order_names = sub["celebrity_name"].tolist()

    name_to_idx = {n: i for i, n in enumerate(roster_names)}
    order_best_to_worst = [name_to_idx[n] for n in order_names]

    return roster_names, roster_scores, order_best_to_worst, order_names


# =========================================================
# 8) 主流程：遍历 season-week，推断每周粉丝投票率 + 后验预测检验
# =========================================================
def run_global_inference(
    csv_path: str,
    n_simulations: int = 100000,
    seed: int = 0,
    out_csv_path: str = "dwts_inferred_fan_votes.csv",
    debug: bool = True,
    ppc_simulations: int = None,     # 后验预测检验采样数（默认跟 n_simulations 一样）
):
    if ppc_simulations is None:
        ppc_simulations = n_simulations

    df = pd.read_csv(csv_path)
    df["elim_week"] = df["results"].apply(parse_elim_week)

    seasons = sorted(df["season"].dropna().unique().astype(int).tolist())
    all_records = []

    for season in seasons:
        sdf = df[df["season"] == season].copy()

        # 赛季 method（按题干常见假设）
        if season in {1, 2} or season >= 28:
            method = "rank"
        else:
            method = "percent"

        # 最大周
        week_nums = []
        for c in sdf.columns:
            m = re.match(r"week(\d+)_judge\d+_score", c)
            if m:
                week_nums.append(int(m.group(1)))
        if not week_nums:
            continue
        max_week = max(week_nums)

        finals_week = find_finals_week(sdf, max_week)

        if debug:
            raw_cnt = int(sdf["elim_week"].notna().sum())
            print(f"[DEBUG] season {season}: results-parsed elim rows={raw_cnt}, max_week={max_week}, finals_week={finals_week}")

        for week in range(1, max_week + 1):
            roster_names, roster_scores, _ = get_week_roster_and_scores(sdf, week)
            if len(roster_names) < 2:
                continue

            # (A) results 明确淘汰者
            elim_names = sdf.loc[sdf["elim_week"] == week, "celebrity_name"].dropna().tolist()

            # (B) next-week zero 推断隐性淘汰
            if len(elim_names) == 0 and week != finals_week:
                inferred = infer_elims_by_nextweek_zero(sdf, week, max_week)
                if inferred:
                    elim_names = inferred
                    if debug:
                        print(f"[DEBUG] season {season} week {week}: inferred by next-week zero -> {elim_names}")

            # (C) finals_week：用 placement 做“最终名次排序约束”
            if len(elim_names) == 0 and week == finals_week:
                finals_pack = infer_finals_order_by_placement(sdf, finals_week)
                if finals_pack is None:
                    if debug:
                        print(f"[DEBUG] season {season} finals_week {finals_week}: placement missing -> skip finals inference")
                    continue

                f_roster_names, f_roster_scores, order_idx, order_names = finals_pack
                eliminated_name = order_names[-1]  # 便于阅读：最差者

                engine = DWTSInferenceEngine(
                    judges_scores=f_roster_scores,
                    contestant_names=f_roster_names,
                    method=method,
                    seed=seed + 100000 * season + 1000 * week + 7,
                )

                # ① finals 排名约束推断（筛选样本）
                mean_votes, std_votes, feasible_rate, num_valid = engine.run_simulation_final_ranking(
                    order_best_to_worst=order_idx,
                    n_simulations=n_simulations,
                )

                # ② 后验/先验预测检验（不筛选样本）：该 finals_week “最差者”在先验下被淘汰的概率
                p_elim, rank_all, p_elim_true, rank_true = engine.posterior_predictive_elim_probs(
                    eliminated_name=eliminated_name,
                    n_simulations=ppc_simulations,
                    tie_mode="split",
                )

                if mean_votes is None:
                    all_records.append({
                        "season": season,
                        "week": week,
                        "method": method,
                        "constraint_type": "final_ranking",
                        "finals_order": " > ".join(order_names),
                        "eliminated": eliminated_name,
                        "status": "no_feasible_solution_finals",
                        "feasible_rate": float(feasible_rate),
                        "num_valid": 0,
                        "n_simulations": int(n_simulations),
                        "p_elim_true": float(p_elim_true),
                        "rank_true": int(rank_true),
                    })
                    # 仍然输出 PPC 的“所有选手淘汰概率/排名”（即便无可行解）
                    for i, (name, jscore) in enumerate(zip(f_roster_names, f_roster_scores)):
                        all_records.append({
                            "season": season,
                            "week": week,
                            "method": method,
                            "constraint_type": "final_ranking",
                            "finals_order": " > ".join(order_names),
                            "eliminated": eliminated_name,
                            "contestant": name,
                            "judge_total": float(jscore),
                            "fan_vote_mean": np.nan,
                            "fan_vote_std": np.nan,
                            "feasible_rate": float(feasible_rate),
                            "num_valid": 0,
                            "n_simulations": int(n_simulations),
                            "p_elim": float(p_elim[i]),
                            "rank_elim": int(rank_all[i]),
                            "p_elim_true": float(p_elim_true),
                            "rank_true": int(rank_true),
                            "status": "no_feasible_solution_finals",
                        })
                    continue

                for i, (name, jscore, mv, sv) in enumerate(zip(f_roster_names, f_roster_scores, mean_votes, std_votes)):
                    all_records.append({
                        "season": season,
                        "week": week,
                        "method": method,
                        "constraint_type": "final_ranking",
                        "finals_order": " > ".join(order_names),
                        "eliminated": eliminated_name,
                        "contestant": name,
                        "judge_total": float(jscore),
                        "fan_vote_mean": float(mv),
                        "fan_vote_std": float(sv),
                        "feasible_rate": float(feasible_rate),
                        "num_valid": int(num_valid),
                        "n_simulations": int(n_simulations),
                        # posterior predictive check (PPC): elimination probability & rank for EACH contestant
                        "p_elim": float(p_elim[i]),
                        "rank_elim": int(rank_all[i]),
                        # keep backward-compatible fields for the "true" eliminated contestant
                        "p_elim_true": float(p_elim_true),
                        "rank_true": int(rank_true),
                        "status": "ok",
                    })
                continue  # finals_week 已处理完

            # 若仍为空：确实没有淘汰且不是 finals_week -> 跳过
            if len(elim_names) == 0:
                continue

            # 常规淘汰周：逐个淘汰者跑一次（含双淘汰）
            for eliminated_name in elim_names:
                if eliminated_name not in roster_names:
                    all_records.append({
                        "season": season,
                        "week": week,
                        "method": method,
                        "constraint_type": "elimination",
                        "eliminated": eliminated_name,
                        "status": "skip_elim_not_in_roster",
                        "feasible_rate": np.nan,
                        "num_valid": 0,
                        "n_simulations": int(n_simulations),
                        "p_elim_true": np.nan,
                        "rank_true": np.nan,
                    })
                    continue

                engine = DWTSInferenceEngine(
                    judges_scores=roster_scores,
                    contestant_names=roster_names,
                    method=method,
                    seed=seed + 100000 * season + 1000 * week,
                )

                # ① 淘汰约束推断（筛选样本：用于 mean/std/feasible）
                mean_votes, std_votes, feasible_rate, num_valid = engine.run_simulation_elimination(
                    eliminated_name=eliminated_name,
                    n_simulations=n_simulations,
                )

                # ② 后验/先验预测检验（不筛选样本）：真实淘汰者在先验下被淘汰的概率/排名
                p_elim, rank_all, p_elim_true, rank_true = engine.posterior_predictive_elim_probs(
                    eliminated_name=eliminated_name,
                    n_simulations=ppc_simulations,
                    tie_mode="split",
                )

                if mean_votes is None:
                    all_records.append({
                        "season": season,
                        "week": week,
                        "method": method,
                        "constraint_type": "elimination",
                        "eliminated": eliminated_name,
                        "status": "no_feasible_solution",
                        "feasible_rate": float(feasible_rate),
                        "num_valid": 0,
                        "n_simulations": int(n_simulations),
                        "p_elim_true": float(p_elim_true),
                        "rank_true": int(rank_true),
                    })
                    # 仍然输出 PPC 的“所有选手淘汰概率/排名”（即便无可行解）
                    for i, (name, jscore) in enumerate(zip(roster_names, roster_scores)):
                        all_records.append({
                            "season": season,
                            "week": week,
                            "method": method,
                            "constraint_type": "elimination",
                            "eliminated": eliminated_name,
                            "contestant": name,
                            "judge_total": float(jscore),
                            "fan_vote_mean": np.nan,
                            "fan_vote_std": np.nan,
                            "feasible_rate": float(feasible_rate),
                            "num_valid": 0,
                            "n_simulations": int(n_simulations),
                            "p_elim": float(p_elim[i]),
                            "rank_elim": int(rank_all[i]),
                            "p_elim_true": float(p_elim_true),
                            "rank_true": int(rank_true),
                            "status": "no_feasible_solution",
                        })
                    continue

                for i, (name, jscore, mv, sv) in enumerate(zip(roster_names, roster_scores, mean_votes, std_votes)):
                    all_records.append({
                        "season": season,
                        "week": week,
                        "method": method,
                        "constraint_type": "elimination",
                        "eliminated": eliminated_name,
                        "contestant": name,
                        "judge_total": float(jscore),
                        "fan_vote_mean": float(mv),
                        "fan_vote_std": float(sv),
                        "feasible_rate": float(feasible_rate),
                        "num_valid": int(num_valid),
                        "n_simulations": int(n_simulations),
                        # posterior predictive check (PPC): elimination probability & rank for EACH contestant
                        "p_elim": float(p_elim[i]),
                        "rank_elim": int(rank_all[i]),
                        # keep backward-compatible fields for the "true" eliminated contestant
                        "p_elim_true": float(p_elim_true),
                        "rank_true": int(rank_true),
                        "status": "ok",
                    })


    out = pd.DataFrame(all_records)
    out.to_csv(out_csv_path, index=False, encoding="utf-8-sig")

    if debug:
        print(f"[DEBUG] output rows={len(out)} -> {out_csv_path}")
    return out


if __name__ == "__main__":
    result_df = run_global_inference(
        csv_path="2026_MCM_Problem_C_Data.csv",
        n_simulations=100000,
        seed=0,
        out_csv_path="dwts_inferred_fan_votes.csv",
        debug=True,
        ppc_simulations=50000,  # 后验预测检验用更小的采样数可加速
    )
   
