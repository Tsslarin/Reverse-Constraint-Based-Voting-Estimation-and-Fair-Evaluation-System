import pandas as pd
import numpy as np

# 可选：混合效应模型
import statsmodels.formula.api as smf

# ============ 1) 读取数据（注意列名） ============
path = r"partner_celebrities_season_placement_detail.csv"
df = pd.read_csv(path)

required = ["ballroom_partner", "season", "celebrity_name", "placement", "season_total_contestants"]
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError(f"缺少列：{missing}\n实际列名：{df.columns.tolist()}")

# 转数值
df["placement"] = pd.to_numeric(df["placement"], errors="coerce")
df["season_total_contestants"] = pd.to_numeric(df["season_total_contestants"], errors="coerce")

# 去掉缺失
df = df.dropna(subset=["ballroom_partner", "season", "placement", "season_total_contestants"]).copy()

# ============ 2) 构造可比的表现指标 perf（0~1 越大越好） ============
# perf = 1 - (placement-1)/(N-1)
# 注意 N=1 会导致除零
df = df[df["season_total_contestants"] > 1].copy()
df["perf"] = 1.0 - (df["placement"] - 1.0) / (df["season_total_contestants"] - 1.0)

# ============ 3) 相关比 η² 函数（partner -> perf） ============
def eta_squared(cat: pd.Series, y: pd.Series, min_count: int = 2) -> float:
    tmp = pd.DataFrame({"cat": cat, "y": y}).dropna()
    if tmp.empty:
        return np.nan

    # 合并稀有舞伴，避免每个舞伴样本过少导致不稳定
    vc = tmp["cat"].value_counts()
    rare = vc[vc < min_count].index
    tmp.loc[tmp["cat"].isin(rare), "cat"] = "Other"

    yv = tmp["y"].to_numpy(dtype=float)
    y_mean = yv.mean()
    ss_total = ((yv - y_mean) ** 2).sum()
    if ss_total <= 0:
        return np.nan

    grp = tmp.groupby("cat")["y"]
    means = grp.mean()
    counts = grp.size()
    ss_between = (counts * (means - y_mean) ** 2).sum()
    return float(ss_between / ss_total)

eta2_partner = eta_squared(df["ballroom_partner"], df["perf"], min_count=2)
print(f"η²(partner → perf) = {eta2_partner:.4f}  （越大说明舞伴解释力越强）")

# ============ 4) 混合效应模型：舞伴随机效应 + ICC ============
# perf ~ 1 + (1|ballroom_partner)
# statsmodels MixedLM 写法：groups=ballroom_partner
md = smf.mixedlm("perf ~ 1", data=df, groups=df["ballroom_partner"])
mfit = md.fit(reml=True)

var_partner = float(mfit.cov_re.iloc[0, 0])   # 舞伴随机效应方差
var_resid   = float(mfit.scale)              # 残差方差
icc = var_partner / (var_partner + var_resid) if (var_partner + var_resid) > 0 else np.nan

print(f"随机效应方差 var_partner = {var_partner:.6f}")
print(f"残差方差 var_resid     = {var_resid:.6f}")
print(f"ICC(舞伴方差占比)      = {icc:.4f}  （越大说明舞伴影响越强）")

# 取舞伴的“收缩后”效应估计（BLUP），可用于更稳的舞伴排名
re = mfit.random_effects
partner_effect = pd.DataFrame({
    "ballroom_partner": list(re.keys()),
    "partner_effect_blup": [float(v.values[0]) for v in re.values()]
})
partner_effect["partner_rank_best"] = partner_effect["partner_effect_blup"].rank(ascending=False, method="min")
partner_effect = partner_effect.sort_values("partner_rank_best")

# 同时输出舞伴带过多少名人
partner_n = df.groupby("ballroom_partner")["celebrity_name"].nunique().rename("n_celebrities").reset_index()
partner_table = partner_effect.merge(partner_n, on="ballroom_partner", how="left")

out_partner = r"partner_effect_rank_blup.csv"
partner_table.to_csv(out_partner, index=False, encoding="utf-8-sig")
print("✅ 已输出舞伴效应（更稳的排名）：", out_partner)

# ============ 5) 置换检验：舞伴是否“显著”影响 perf ============
# 思路：在每个 season 内打乱舞伴分配（保持赛季结构不变），重复计算 η²
def perm_test_eta2(df_in: pd.DataFrame, B: int = 2000, seed: int = 0) -> float:
    rng = np.random.default_rng(seed)
    true_eta2 = eta_squared(df_in["ballroom_partner"], df_in["perf"], min_count=2)

    perm_vals = []
    for _ in range(B):
        dfp = df_in.copy()
        # 在赛季内打乱舞伴
        dfp["ballroom_partner"] = (
            dfp.groupby("season")["ballroom_partner"]
               .transform(lambda s: rng.permutation(s.to_numpy()))
        )
        perm_vals.append(eta_squared(dfp["ballroom_partner"], dfp["perf"], min_count=2))

    perm_vals = np.array([v for v in perm_vals if np.isfinite(v)])
    # p 值：置换后 >= 真实值 的比例（右尾）
    p = (np.sum(perm_vals >= true_eta2) + 1) / (len(perm_vals) + 1)
    return true_eta2, p

true_eta2, pval = perm_test_eta2(df, B=2000, seed=42)
print(f"置换检验：真实η²={true_eta2:.4f}, p-value≈{pval:.4f}")
