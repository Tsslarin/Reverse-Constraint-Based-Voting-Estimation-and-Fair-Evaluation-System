import pandas as pd

# 1) 读取数据
df = pd.read_excel("Rank.xlsx")   # 如果你的文件名/路径不同，改这里

# 2) 排序（可选，但建议：保证“保留第一条”有确定性）
df = df.sort_values(["season", "week"]).reset_index(drop=True)

# 3) 去重：每个 season-week 只保留一行（keep='first' 可改成 'last'）
df_one = df.drop_duplicates(subset=["season", "week"], keep="first").reset_index(drop=True)

# 4) 输出
df_one.to_excel("Rank_one_row_per_season_week.xlsx", index=False)
print("输出完成：Rank_one_row_per_season_week.xlsx")
