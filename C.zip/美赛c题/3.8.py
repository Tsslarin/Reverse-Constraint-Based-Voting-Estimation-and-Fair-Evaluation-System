import pandas as pd
import numpy as np

# ===================== 1) 读取数据（列名必须与表格完全一致） =====================
path = r"2026_MCM_Problem_C_Data_含赛季人数.csv"
df = pd.read_csv(path)

required_cols = [
    "celebrity_name",
    "celebrity_industry",
    "celebrity_homecountry/region",
    "placement",
    "season_total_contestants",
]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"缺少必要列：{missing}\n实际列名为：{df.columns.tolist()}")

# 转数值
df["placement"] = pd.to_numeric(df["placement"], errors="coerce")
df["season_total_contestants"] = pd.to_numeric(df["season_total_contestants"], errors="coerce")

# 去掉关键缺失
df = df.dropna(subset=["celebrity_industry", "celebrity_homecountry/region", "placement", "season_total_contestants"]).copy()
df = df[df["season_total_contestants"] > 1].copy()

# ===================== 2) 名次归一化（消除不同赛季人数影响） =====================
# placement_norm 越大越好：冠军=1，最后一名=0
df["placement_norm"] = 1.0 - (df["placement"] - 1.0) / (df["season_total_contestants"] - 1.0)

# ===================== 3) 相关比 η²（Correlation Ratio squared） =====================
def eta_squared(cat: pd.Series, y: pd.Series, min_count: int = 2) -> float:
    """
    类别变量 cat 对连续变量 y 的相关比 η²
    min_count：样本过少的类别合并为 'Other'，避免极小类导致不稳定
    """
    tmp = pd.DataFrame({"cat": cat, "y": y}).dropna()
    if tmp.empty:
        return np.nan

    if min_count is not None and min_count > 1:
        vc = tmp["cat"].value_counts(dropna=False)
        rare = vc[vc < min_count].index
        tmp.loc[tmp["cat"].isin(rare), "cat"] = "Other"

    yv = tmp["y"].astype(float).to_numpy()
    y_mean = yv.mean()
    ss_total = ((yv - y_mean) ** 2).sum()
    if ss_total <= 0:
        return np.nan

    grp = tmp.groupby("cat")["y"]
    means = grp.mean()
    counts = grp.size()
    ss_between = (counts * (means - y_mean) ** 2).sum()
    return float(ss_between / ss_total)

# ===================== 4) 计算行业/国籍 与 归一化名次的相关比 η² =====================
eta2_industry = eta_squared(df["celebrity_industry"], df["placement_norm"], min_count=2)
eta2_country  = eta_squared(df["celebrity_homecountry/region"], df["placement_norm"], min_count=2)

print("=== 相关比 η²（类别 -> 归一化名次 placement_norm）===")
print(f"celebrity_industry -> placement_norm : eta² = {eta2_industry:.4f}")
print(f"celebrity_homecountry/region -> placement_norm : eta² = {eta2_country:.4f}")

# ===================== 5) 回填并输出新文件 =====================
out_with_norm = r"2026_MCM_Problem_C_Data_含赛季人数_含归一化名次.csv"
df.to_csv(out_with_norm, index=False, encoding="utf-8-sig")
print("✅ 已输出（含 placement_norm）：", out_with_norm)

out_eta2 = r"eta2_industry_country_vs_normalized_placement.csv"
pd.DataFrame([{
    "eta2_industry": eta2_industry,
    "eta2_country_region": eta2_country
}]).to_csv(out_eta2, index=False, encoding="utf-8-sig")
print("✅ 已输出（η²结果）：", out_eta2)
