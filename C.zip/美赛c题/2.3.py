import pandas as pd
import numpy as np

# =========================
# 路径（按你的实际文件名/路径改）
# =========================
VOTES_PATH = "dwts_inferred_fan_votes - 第二问·.csv"
OFFICIAL_PATH = "2026_MCM_Problem_C_Data.csv"
OUT_XLSX = "sim-all-seasonrank_percent_with_ranks.xlsx"

TARGET_SEASONS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34]

# =========================
# 1) 读取数据
# =========================
votes = pd.read_csv(VOTES_PATH)
votes = votes.loc[:, ~votes.columns.str.contains(r"^Unnamed")].copy()

need_cols = ["season", "week", "contestant", "judge_total", "estimated_votes_total"]
missing = [c for c in need_cols if c not in votes.columns]
if missing:
    raise ValueError(f"推断票数表缺少列：{missing}，请检查 {VOTES_PATH} 的列名。")  
votes["season"] = pd.to_numeric(votes["season"], errors="coerce").astype("Int64")
votes["week"] = pd.to_numeric(votes["week"], errors="coerce").astype("Int64")
votes["judge_total"] = pd.to_numeric(votes["judge_total"], errors="coerce")
votes["estimated_votes_total"] = pd.to_numeric(votes["estimated_votes_total"], errors="coerce")
votes = votes.dropna(subset=["season", "week", "contestant", "judge_total"]).copy()

# 官方表（用于取真实冠军对照，可选）
official = pd.read_csv(OFFICIAL_PATH)
# 真实冠军：placement==1
# 注：列名来自你提供的官方数据文件
real_champs = {}
if "season" in official.columns and "placement" in official.columns and "celebrity_name" in official.columns:
    tmp = official.loc[official["placement"] == 1, ["season", "celebrity_name"]].dropna()
    real_champs = dict(zip(tmp["season"].astype(int), tmp["celebrity_name"].astype(str)))

# =========================
# 2) 一些工具函数
# =========================
def is_no_vote_week(g: pd.DataFrame) -> bool:
    """该周是否无投票：estimated_votes_total 全 NaN 或全 0"""
    s = g["estimated_votes_total"]
    if s.isna().all():
        return True
    # 如果不是全NaN，但全是0也视为无投票
    if (s.fillna(0) == 0).all():
        return True
    return False

def compute_week_ranks(g: pd.DataFrame) -> pd.DataFrame:
    """
    对单周数据计算：
    - judge_rank (1=最高分)
    - fan_rank   (1=最高票)
    - Rank法综合：sum_ranks（越小越好）+ overall_rank_rankmethod (1=最好)
    - Percent法综合：combined_percent（越大越好）+ overall_rank_percent (1=最好)
    """
    gg = g.copy()

    # judge_rank：分数越高 rank越小
    gg["judge_rank"] = gg["judge_total"].rank(ascending=False, method="min")

    # fan_rank：票数越高 rank越小；若有NaN，用很差的处理（但我们会跳过无投票周）
    gg["fan_rank"] = gg["estimated_votes_total"].rank(ascending=False, method="min")

    # ---------- Rank 法 ----------
    gg["sum_ranks"] = gg["judge_rank"] + gg["fan_rank"]

    # overall_rank_rankmethod：sum_ranks 从小到大排（1=最好）
    # tie-break：sum_ranks -> fan_rank -> judge_rank -> contestant字母序
    gg = gg.sort_values(
        by=["sum_ranks", "fan_rank", "judge_rank", "contestant"],
        ascending=[True, True, True, True]
    )
    gg["overall_rank_rankmethod"] = np.arange(1, len(gg) + 1)

    # ---------- Percent 法 ----------
    sum_j = gg["judge_total"].sum()
    sum_v = gg["estimated_votes_total"].sum()

    # 兜底：防止极端情况
    if (sum_j <= 0) or (sum_v <= 0):
        gg["judge_percent"] = np.nan
        gg["fan_percent"] = np.nan
        gg["combined_percent"] = np.nan
        gg = gg.sort_values(["estimated_votes_total", "judge_total", "contestant"],
                            ascending=[False, False, True])
        gg["overall_rank_percent"] = np.arange(1, len(gg) + 1)
        return gg

    gg["judge_percent"] = gg["judge_total"] / sum_j
    gg["fan_percent"] = gg["estimated_votes_total"] / sum_v
    gg["combined_percent"] = gg["judge_percent"] + gg["fan_percent"]

    # overall_rank_percent：combined_percent 从大到小排（1=最好）
    # tie-break：combined_percent -> fan_percent -> judge_percent -> contestant字母序
    gg = gg.sort_values(
        by=["combined_percent", "fan_percent", "judge_percent", "contestant"],
        ascending=[False, False, False, True]
    )
    gg["overall_rank_percent"] = np.arange(1, len(gg) + 1)

    return gg

def simulate_one_season(season: int):
    """
    核心模拟：
    - 先过滤出“有效周”（有投票的周）
    - 对每个有效周算排名
    - 推断本周淘汰人数 k = 本周人数 - 下一有效周人数（最后有效周 k=0）
    - Rank法淘汰：overall_rank_rankmethod 最差的 k 人（排名大的）
    - Percent法淘汰：overall_rank_percent 最差的 k 人
    - 冠军：最后有效周综合排名第1名
    """
    d = votes[votes["season"] == season].copy()
    if d.empty:
        raise ValueError(f"votes表中找不到 season={season} 的数据。")

    # 找有效周：有投票的周
    week_groups = {w: g for w, g in d.groupby("week", sort=True)}
    valid_weeks = []
    for w in sorted(week_groups.keys()):
        if not is_no_vote_week(week_groups[w]):
            valid_weeks.append(int(w))

    if len(valid_weeks) < 2:
        raise ValueError(f"season={season} 的有效周太少（<2），无法做淘汰推断。")

    detail_rows = []
    weekly_rows = []

    # 预先算每个有效周人数
    n_by_week = {w: week_groups[w]["contestant"].nunique() for w in valid_weeks}

    for i, w in enumerate(valid_weeks):
        g = week_groups[w].copy()
        g_ranked = compute_week_ranks(g)

        n_now = int(n_by_week[w])
        if i < len(valid_weeks) - 1:
            w_next = valid_weeks[i + 1]
            n_next = int(n_by_week[w_next])
            k = max(n_now - n_next, 0)
        else:
            k = 0

        # 本周淘汰名单：取“最差k人”
        # Rank法：overall_rank_rankmethod 越大越差
        elim_rank_list = []
        if k > 0:
            worst_rank = g_ranked.sort_values(
                ["overall_rank_rankmethod"], ascending=False
            ).head(k)
            elim_rank_list = worst_rank["contestant"].astype(str).tolist()

        # Percent法：overall_rank_percent 越大越差
        elim_pct_list = []
        if k > 0:
            worst_pct = g_ranked.sort_values(
                ["overall_rank_percent"], ascending=False
            ).head(k)
            elim_pct_list = worst_pct["contestant"].astype(str).tolist()

        # 给明细打标记
        g_ranked["season"] = season
        g_ranked["week"] = int(w)
        g_ranked["elim_by_rank"] = g_ranked["contestant"].astype(str).isin(elim_rank_list)
        g_ranked["elim_by_percent"] = g_ranked["contestant"].astype(str).isin(elim_pct_list)

        detail_rows.append(g_ranked)

        weekly_rows.append({
            "season": season,
            "week": int(w),
            "n_contestants": n_now,
            "n_elims_inferred": int(k),
            "elim_by_rank": ", ".join(elim_rank_list) if elim_rank_list else "-",
            "elim_by_percent": ", ".join(elim_pct_list) if elim_pct_list else "-"
        })

    detail = pd.concat(detail_rows, ignore_index=True)
    weekly = pd.DataFrame(weekly_rows)

    # 冠军：最后有效周综合排名第1
    final_week = valid_weeks[-1]
    final_detail = detail[detail["week"] == final_week].copy()

    champ_rank = final_detail.loc[
        final_detail["overall_rank_rankmethod"] == 1, "contestant"
    ].astype(str).iloc[0]
    champ_pct = final_detail.loc[
        final_detail["overall_rank_percent"] == 1, "contestant"
    ].astype(str).iloc[0]

    champs = {
        "season": season,
        "final_valid_week": int(final_week),
        "champion_by_rank": champ_rank,
        "champion_by_percent": champ_pct,
        "real_champion_if_available": real_champs.get(season, np.nan)
    }

    # 为了更直观，整理一下 detail 的列顺序
    keep_order = [
        "season", "week", "contestant",
        "judge_total", "estimated_votes_total",
        "judge_rank", "fan_rank",
        "sum_ranks", "overall_rank_rankmethod",
        "judge_percent", "fan_percent", "combined_percent", "overall_rank_percent",
        "elim_by_rank", "elim_by_percent"
    ]
    # 有些列可能不存在（极端兜底），安全处理
    keep_order = [c for c in keep_order if c in detail.columns]
    detail = detail[keep_order].copy()

    return weekly, detail, champs

# =========================
# 3) 运行四个赛季 + 输出
# =========================
weekly_all = []
detail_all = []
champs_all = []

for s in TARGET_SEASONS:
    wtab, dtab, champ = simulate_one_season(s)
    weekly_all.append(wtab)
    detail_all.append(dtab)
    champs_all.append(champ)

weekly_all = pd.concat(weekly_all, ignore_index=True).sort_values(["season", "week"])
detail_all = pd.concat(detail_all, ignore_index=True).sort_values(["season", "week", "overall_rank_rankmethod"])
champs_df = pd.DataFrame(champs_all).sort_values("season")

# 导出 Excel：汇总 + 每赛季独立sheet + 全明细
with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as writer:
    champs_df.to_excel(writer, index=False, sheet_name="Champions")
    weekly_all.to_excel(writer, index=False, sheet_name="Weekly_Elims")
    detail_all.to_excel(writer, index=False, sheet_name="Detail_All")
    # 每个赛季再单独给一个sheet（可选但很方便）
    for s in TARGET_SEASONS:
        weekly_all[weekly_all["season"] == s].to_excel(writer, index=False, sheet_name=f"S{s}_Weekly")
        detail_all[detail_all["season"] == s].to_excel(writer, index=False, sheet_name=f"S{s}_Detail")

print("✅ 已输出：", OUT_XLSX)
print("\n=== Champions ===")
print(champs_df.to_string(index=False))
print("\n=== Weekly eliminations (first 30 rows) ===")
print(weekly_all.head(30).to_string(index=False))
