import pandas as pd
import numpy as np
from pathlib import Path

# =========================
# 0) 你只需要改这里
# =========================
DATA_PATH = Path(r"dwts_inferred_fan_votes - 第二问·.csv")  # 你的csv
OUT_XLSX  = Path(r"FVVS_sim_2_4_11_27_lambda1p8_wJ0p19.xlsx")

SEASONS = [2, 4, 11, 27]

# FVVS 参数（你已经估出来的）
LAMBDA = 1.8
WJ     = 0.19

# Modified Borda 的凸性（>1 会更奖励头部，和你前面标定代码保持一致即可）
GAMMA  = 1.5


# =========================
# 1) 读取数据（列名按你真实表格写死）
# =========================
if not DATA_PATH.exists():
    raise FileNotFoundError(f"找不到文件：{DATA_PATH.resolve()}")

df = pd.read_csv(DATA_PATH, encoding="utf-8-sig")

needed = ["season", "week", "contestant", "judge_total", "estimated_votes_total"]
miss = [c for c in needed if c not in df.columns]
if miss:
    raise ValueError(f"缺少列：{miss}\n当前列名：{df.columns.tolist()}")

df = df[needed].copy()
df["contestant"] = df["contestant"].astype(str).str.strip()

df["season"] = pd.to_numeric(df["season"], errors="coerce")
df["week"]   = pd.to_numeric(df["week"], errors="coerce")
df["judge_total"] = pd.to_numeric(df["judge_total"], errors="coerce").fillna(0.0)
df["estimated_votes_total"] = pd.to_numeric(df["estimated_votes_total"], errors="coerce").fillna(0.0)

df = df.dropna(subset=["season", "week", "contestant"]).copy()
df["season"] = df["season"].astype(int)
df["week"]   = df["week"].astype(int)

df = df[df["season"].isin(SEASONS)].copy()
df = df.sort_values(["season", "week", "contestant"]).reset_index(drop=True)


# =========================
# 2) 推断每周淘汰人数 elim_k（人数差法）
# =========================
wk_n = (
    df.groupby(["season", "week"])["contestant"]
      .nunique()
      .reset_index(name="n")
      .sort_values(["season", "week"])
)
wk_n["n_next"] = wk_n.groupby("season")["n"].shift(-1)
wk_n["elim_k"] = (wk_n["n"] - wk_n["n_next"]).fillna(0).astype(int)
wk_n.loc[wk_n["elim_k"] < 0, "elim_k"] = 0  # 防异常
elim_k_map = {(r.season, r.week): int(r.elim_k) for r in wk_n.itertuples(index=False)}


# =========================
# 3) FVVS：计算当周综合分 u
#     u = wJ*Sj + (1-wJ)*Fcap
#   Sj：由 judge_total 排名 -> [0,1] -> ^GAMMA
#   Fcap：vote_share capped by lambda * max(judge_share)
# =========================
def compute_week_u(dfw: pd.DataFrame) -> pd.DataFrame:
    out = dfw[["season", "week", "contestant", "judge_total", "estimated_votes_total"]].copy()
    N = len(out)
    if N <= 1:
        out["judge_share"] = 0.0
        out["vote_share"] = 0.0
        out["Sj"] = 0.0
        out["Fcap"] = 0.0
        out["u"] = 0.0
        return out

    sumJ = out["judge_total"].sum()
    sumV = out["estimated_votes_total"].sum()

    out["judge_share"] = out["judge_total"] / sumJ if sumJ != 0 else 0.0
    out["vote_share"]  = out["estimated_votes_total"] / sumV if sumV != 0 else 0.0

    # judge_rank: 1=最好
    out["judge_rank"] = out["judge_total"].rank(method="average", ascending=False)

    # Modified Borda: best=1, worst=0
    norm_rank = (N - out["judge_rank"]) / (N - 1)
    out["Sj"] = np.power(norm_rank, GAMMA)

    # cap：fan <= lambda * max(judge_share)
    cap_level = LAMBDA * out["judge_share"].max()
    out["Fcap"] = np.minimum(out["vote_share"].values, cap_level)

    out["u"] = WJ * out["Sj"] + (1 - WJ) * out["Fcap"]
    return out


# =========================
# 4) 赛季模拟（带 LOCF 插补，确保能完整“反事实”跑完）
# =========================
def simulate_season(season_id: int):
    df_s = df[df["season"] == season_id].copy()
    weeks = sorted(df_s["week"].unique())

    # 初始在场：该赛季最早一周出现的所有人
    w0 = weeks[0]
    active = set(df_s[df_s["week"] == w0]["contestant"].unique())

    # 保存每个选手最后一次观察到的分数（用于 LOCF 插补）
    last_obs = {}  # name -> (judge_total, votes_total)

    weekly_rows = []
    eliminated_order = []  # 记录淘汰顺序：早淘汰更差

    for w in weeks:
        k = elim_k_map.get((season_id, w), 0)
        dfw_real = df_s[df_s["week"] == w].copy()

        # 更新 last_obs（对本周真实出现的人）
        for r in dfw_real.itertuples(index=False):
            last_obs[r.contestant] = (float(r.judge_total), float(r.estimated_votes_total))

        # 构造“本周用于模拟”的参赛名单 = 当前 active
        # 对 active 里但本周真实数据缺失的人，用 LOCF 补一行（反事实存活所需）
        rows = []
        present_names = set(dfw_real["contestant"].tolist())
        for name in sorted(active):
            if name in present_names:
                rr = dfw_real[dfw_real["contestant"] == name].iloc[0]
                rows.append({
                    "season": season_id,
                    "week": w,
                    "contestant": name,
                    "judge_total": float(rr["judge_total"]),
                    "estimated_votes_total": float(rr["estimated_votes_total"]),
                    "imputed": 0
                })
            else:
                # LOCF：若连 last_obs 都没有，就给 0（极少发生）
                jt, vt = last_obs.get(name, (0.0, 0.0))
                rows.append({
                    "season": season_id,
                    "week": w,
                    "contestant": name,
                    "judge_total": jt,
                    "estimated_votes_total": vt,
                    "imputed": 1
                })

        dfw = pd.DataFrame(rows)
        if dfw.empty:
            continue

        scored = compute_week_u(dfw)

        if k <= 0:
            weekly_rows.append({
                "season": season_id,
                "week": w,
                "elim_k": 0,
                "eliminated_FVVS": "",
                "active_n_before": len(active),
                "n_imputed": int(dfw["imputed"].sum())
            })
            continue

        # 淘汰规则：u 最低的 k 人淘汰；tie-break：judge_total 更低者先淘汰
        scored = scored.merge(dfw[["contestant", "imputed"]], on="contestant", how="left")
        scored = scored.sort_values(["u", "judge_total"], ascending=[True, True]).reset_index(drop=True)
        elim_names = scored.head(k)["contestant"].tolist()

        for name in elim_names:
            eliminated_order.append((w, name))
            if name in active:
                active.remove(name)

        weekly_rows.append({
            "season": season_id,
            "week": w,
            "elim_k": k,
            "eliminated_FVVS": "; ".join(elim_names),
            "active_n_before": len(active) + k,
            "n_imputed": int(dfw["imputed"].sum())
        })

    # 赛季结束：剩余 active 为决赛/最后留存者
    # 用最后一周的 u 给他们排冠亚季（u 越高越好）
    last_week = weeks[-1]
    # 为最后一周也构造一份 dfw（同样含 LOCF）
    rows = []
    df_last_real = df_s[df_s["week"] == last_week].copy()
    present_last = set(df_last_real["contestant"].tolist())
    for name in sorted(active):
        if name in present_last:
            rr = df_last_real[df_last_real["contestant"] == name].iloc[0]
            rows.append({
                "season": season_id,
                "week": last_week,
                "contestant": name,
                "judge_total": float(rr["judge_total"]),
                "estimated_votes_total": float(rr["estimated_votes_total"]),
            })
        else:
            jt, vt = last_obs.get(name, (0.0, 0.0))
            rows.append({
                "season": season_id,
                "week": last_week,
                "contestant": name,
                "judge_total": jt,
                "estimated_votes_total": vt,
            })
    df_last = pd.DataFrame(rows)
    last_scored = compute_week_u(df_last)
    last_scored = last_scored.sort_values(["u", "judge_total"], ascending=[False, False]).reset_index(drop=True)
    finalists_ranked = last_scored["contestant"].tolist()  # 冠军->更差

    # 最终排名：
    # - finalists：按 last_week 的 u 排 1..m
    # - 其他人：越晚淘汰名次越靠前（更好）
    all_players = set(df_s["contestant"].unique()) | set([x for _, x in eliminated_order]) | set(finalists_ranked)
    total_players = len(all_players)

    ranking_rows = []
    place = 1
    for name in finalists_ranked:
        ranking_rows.append({
            "season": season_id,
            "final_place": place,
            "contestant": name,
            "note": f"finalists ranked by FVVS in week {last_week}"
        })
        place += 1

    # eliminated_order: 早->晚，所以反过来 晚->早
    eliminated_reverse = list(reversed(eliminated_order))
    remaining_places = list(range(place, total_players + 1))
    for (w, name), pl in zip(eliminated_reverse, remaining_places):
        ranking_rows.append({
            "season": season_id,
            "final_place": pl,
            "contestant": name,
            "note": f"eliminated by FVVS in week {w}"
        })

    week_df = pd.DataFrame(weekly_rows).sort_values(["season", "week"]).reset_index(drop=True)
    rank_df = pd.DataFrame(ranking_rows).sort_values(["season", "final_place"]).reset_index(drop=True)
    return week_df, rank_df, last_scored


# =========================
# 5) 跑四个赛季并输出
# =========================
all_week = []
all_rank = []
lastweek_debug = {}

for s in SEASONS:
    wdf, rdf, last_sc = simulate_season(s)
    all_week.append(wdf)
    all_rank.append(rdf)
    lastweek_debug[s] = last_sc

week_all = pd.concat(all_week, ignore_index=True)
rank_all = pd.concat(all_rank, ignore_index=True)

with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as writer:
    week_all.to_excel(writer, sheet_name="weekly_eliminations", index=False)
    rank_all.to_excel(writer, sheet_name="final_rankings", index=False)
    for s in SEASONS:
        lastweek_debug[s].to_excel(writer, sheet_name=f"lastweek_scores_s{s}", index=False)

print("Done!")
print("Saved:", OUT_XLSX.resolve())
print(f"Params: lambda={LAMBDA}, wJ={WJ}, gamma={GAMMA}")
