import pandas as pd

# ====== 1) 读入数据 ======
votes_path = r"dwts_inferred_fan_votes - 第二问·.csv"
partner_path = r"partner_celebrities_season_placement_detail.csv"

df_votes = pd.read_csv(votes_path)
df_partner = pd.read_csv(partner_path)

# ====== 2) 统一清洗姓名（去掉NBSP与首尾空格）======
def clean_name(s: pd.Series) -> pd.Series:
    return (s.astype(str)
              .str.replace("\u00A0", " ", regex=False)  # NBSP -> 空格
              .str.strip())

df_votes["contestant_clean"] = clean_name(df_votes["contestant"])
df_partner["celebrity_name_clean"] = clean_name(df_partner["celebrity_name"])

# ====== 3) 计算“名人-赛季”的参赛周数、总分、总票、平均分/票 ======
# 参赛周数：用该人该赛季出现的周数（通常每周一行）计数
season_avgs = (
    df_votes
    .groupby(["season", "contestant_clean"], as_index=False)
    .agg(
        weeks_participated=("week", "nunique"),
        judge_total_sum=("judge_total", "sum"),
        votes_total_sum=("estimated_votes_total", "sum"),
    )
)

season_avgs["season_avg_judge_total"] = (
    season_avgs["judge_total_sum"] / season_avgs["weeks_participated"]
)
season_avgs["season_avg_estimated_votes_total"] = (
    season_avgs["votes_total_sum"] / season_avgs["weeks_participated"]
)

# 只保留要回填的列（列名注意：新增列用清晰英文名，原列不改）
season_avgs_keep = season_avgs[[
    "season", "contestant_clean", "weeks_participated",
    "season_avg_judge_total", "season_avg_estimated_votes_total"
]]

# ====== 4) 回填到“投票/分数周表” df_votes ======
df_votes = df_votes.merge(
    season_avgs_keep,
    on=["season", "contestant_clean"],
    how="left",
    validate="m:1"  # 每个(season, contestant_clean)只有一条平均值记录
)

# （可选）不想保留清洗列的话就删掉
df_votes.drop(columns=["contestant_clean"], inplace=True)

# ====== 5) 合并到“舞伴-名人-赛季表” df_partner（便于分析舞伴影响）======
# 先把season_avgs的键改成 celebrity_name_clean 以便合并
season_avgs_for_partner = season_avgs.rename(columns={"contestant_clean": "celebrity_name_clean"})[[
    "season", "celebrity_name_clean", "weeks_participated",
    "season_avg_judge_total", "season_avg_estimated_votes_total"
]]

df_partner = df_partner.merge(
    season_avgs_for_partner,
    on=["season", "celebrity_name_clean"],
    how="left",
    validate="m:1"
)

# （可选）删除清洗列
df_partner.drop(columns=["celebrity_name_clean"], inplace=True)

# ====== 6) 检查是否仍有没匹配上的（建议你看一眼）======
missing_partner = df_partner[df_partner["season_avg_judge_total"].isna()][["season", "celebrity_name", "ballroom_partner"]]
if len(missing_partner) > 0:
    print("以下记录在合并时未匹配到分数/投票平均值（可能是姓名拼写不一致）：")
    print(missing_partner.to_string(index=False))
else:
    print("舞伴表已全部成功匹配到赛季平均分与平均票。")

# ====== 7) 输出到新文件（不覆盖原文件）======
out_votes_csv = "dwts_inferred_fan_votes_含赛季均值.csv"
out_partner_csv = "partner_celebrities_season_placement_detail_含赛季均值.csv"

df_votes.to_csv(out_votes_csv, index=False, encoding="utf-8-sig")
df_partner.to_csv(out_partner_csv, index=False, encoding="utf-8-sig")

print("已输出：")
print(out_votes_csv)
print(out_partner_csv)
