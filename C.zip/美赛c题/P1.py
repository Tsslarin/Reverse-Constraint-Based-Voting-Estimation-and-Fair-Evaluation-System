import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ===== 1) 读取数据 =====
file_path = "fan_vote.xlsx"  # 改成你的文件名
df = pd.read_excel(file_path)

# 合并单元格导致的 NaN：向下填充
df[["Season", "Week"]] = df[["Season", "Week"]].ffill()

# 保持原始顺序
df = df.reset_index(drop=True)

# ===== 2) 构造分组信息与颜色映射 =====
# 用 Season + Week 做颜色分组（保证同一赛季同一周颜色一致）
df["SeasonWeek"] = df["Season"].astype(str) + " | " + df["Week"].astype(str)

seasonweek_in_order = df["SeasonWeek"].drop_duplicates().tolist()
seasons_in_order = df["Season"].drop_duplicates().tolist()

cmap = plt.get_cmap("tab20")
seasonweek_color = {g: cmap(i % 20) for i, g in enumerate(seasonweek_in_order)}
bar_colors = df["SeasonWeek"].map(seasonweek_color).tolist()

# 基础数据
x = np.arange(len(df))
names = df["Name"].astype(str).tolist()
vote_mean = df["Fan_vote_mean"].astype(float).to_numpy()
vote_std = df["Fan_vote_std"].astype(float).to_numpy()

# ===== 3) 边界位置：赛季边界、周边界 =====
season_change_idx = np.where(df["Season"].values[:-1] != df["Season"].values[1:])[0]
season_boundaries = (season_change_idx + 0.5).tolist()

# “周边界”这里按 SeasonWeek 变化切分（同一赛季不同周就会切）
week_change_idx = np.where(df["SeasonWeek"].values[:-1] != df["SeasonWeek"].values[1:])[0]
week_boundaries = (week_change_idx + 0.5).tolist()

# 赛季区间（用于右轴折线分段）
season_data_ranges = []
for s in seasons_in_order:
    idx = df.index[df["Season"] == s].to_numpy()
    if len(idx) > 0:
        season_data_ranges.append((idx.min(), idx.max()))

# ===== 4) 初始化图表 =====
plt.rcParams["font.sans-serif"] = ["SimHei", "Arial Unicode MS", "Noto Sans CJK SC", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

# 底部留更大空间：两行标签（Week + Season）
fig, ax1 = plt.subplots(figsize=(18, 8), dpi=180, gridspec_kw={"bottom": 0.28})

# --- 柱状图：Mean ---
ax1.bar(
    x, vote_mean,
    color=bar_colors,
    edgecolor="white",
    linewidth=0.8,
    alpha=0.95,
    label="Fan Vote Mean"
)
ax1.set_ylabel("Fan Vote Mean", fontsize=11)
ax1.set_ylim(0, max(vote_mean) * 1.25)

# --- 右轴折线：Std（按赛季分段，避免跨赛季连接） ---
ax2 = ax1.twinx()
for i, (start_idx, end_idx) in enumerate(season_data_ranges):
    season_x = x[start_idx:end_idx + 1]
    season_std = vote_std[start_idx:end_idx + 1]
    ax2.plot(
        season_x, season_std,
        color="#87CEEB",
        linewidth=2.2,
        marker="o",
        markersize=4.5,
        alpha=0.9,
        label="Fan Vote Std" if i == 0 else ""
    )

ax2.set_ylabel("Fan Vote Std", fontsize=11, color="#87CEEB")
ax2.tick_params(axis="y", colors="#87CEEB")
ax2.set_ylim(0, max(vote_std) * 1.35)
ax2.spines["right"].set_color("#87CEEB")

# ===== 5) X轴：人名 =====
ax1.set_xticks(x)
ax1.set_xticklabels(
    names,
    rotation=60,
    ha="right",
    fontsize=5,
    linespacing=1.2
)

# ===== 6) 分隔线 =====
# 赛季边界：更明显
for b in season_boundaries:
    ax1.axvline(b, color="#ECF1A3", linestyle="--", linewidth=1.6, alpha=0.9)

# 周边界：更轻
for b in week_boundaries:
    ax1.axvline(b, color="#999999", linestyle=":", linewidth=1.0, alpha=0.55)

# ===== 7) 两行标签：Week（第一行） + Season（第二行） =====
# 第一行：Week（按 SeasonWeek 分组，但只显示 Week 文本）
# y_week 放在“人名下方一点”
y_week = -0.22
for g in seasonweek_in_order:
    idx = df.index[df["SeasonWeek"] == g].to_numpy()
    x_center = (idx.min() + idx.max()) / 2.0
    week_text = str(df.loc[idx.min(), "Week"])
    ax1.text(
        x_center, y_week,
        week_text,
        ha="center",
        va="top",
        fontsize=10,
        bbox=dict(boxstyle="round,pad=0.25", facecolor="#F5F5F5", edgecolor="#DDDDDD", alpha=0.85),
        transform=ax1.get_xaxis_transform()
    )

# 第二行：Season（最下方）
y_season = -0.35
for s in seasons_in_order:
    idx = df.index[df["Season"] == s].to_numpy()
    if len(idx) == 0:
        continue
    x_center = (idx.min() + idx.max()) / 2.0
    ax1.text(
        x_center, y_season,
        str(s),
        ha="center",
        va="top",
        fontsize=11,
        bbox=dict(boxstyle="round,pad=0.30", facecolor="#EFEFEF", edgecolor="#CCCCCC", alpha=0.90),
        transform=ax1.get_xaxis_transform()
    )

# ===== 8) 美化与导出 =====
ax1.grid(axis="y", linestyle="--", alpha=0.25, color="#EEEEEE")

handles1, labels1 = ax1.get_legend_handles_labels()
handles2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(
    handles1 + handles2,
    labels1 + labels2,
    loc="upper left",
    frameon=True,
    framealpha=0.9,
    fontsize=10
)

ax1.set_title("Fan Vote Mean and Std", fontsize=14, pad=20)

plt.tight_layout()
plt.savefig("fan_vote_bar_line_week_then_season.png", bbox_inches="tight", dpi=180)
plt.show()
