import pandas as pd

# 1) 读取原始表格（列名以文件为准）
in_path = r"2026_MCM_Problem_C_Data.csv"
df = pd.read_csv(in_path)

# 2) 基础校验：必须存在这些列名（与表格列名完全一致）
need_cols = ["celebrity_name", "season", "placement"]
missing = [c for c in need_cols if c not in df.columns]
if missing:
    raise ValueError(f"缺少列：{missing}\n当前列名：{df.columns.tolist()}")

# 3) 计算每个赛季的参加人数（名人去重计数）
season_counts = (
    df.groupby("season")["celebrity_name"]
      .nunique()
      .rename("season_total_contestants")
      .reset_index()
)

# 4) 回填到原表（不改原有列名，只新增 season_total_contestants）
df = df.merge(season_counts, on="season", how="left", validate="m:1")

# 5) 如果你想单独输出“名人-赛季”的汇总表（只保留关键列）
summary = (
    df[["celebrity_name", "season", "placement", "season_total_contestants"]]
      .drop_duplicates()
      .sort_values(["season", "placement", "celebrity_name"])
)

# 6) 输出为新文件（不覆盖原文件）
out_full = r"2026_MCM_Problem_C_Data_含赛季人数.csv"
out_summary = r"celebrity_season_placement_and_contestants.csv"

df.to_csv(out_full, index=False, encoding="utf-8-sig")
summary.to_csv(out_summary, index=False, encoding="utf-8-sig")

print("已输出：")
print(out_full)
print(out_summary)
