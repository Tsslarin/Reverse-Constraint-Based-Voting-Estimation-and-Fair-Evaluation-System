import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import patheffects

# =========================
# 1) 读取文件
# =========================
file_path = "Rank_one_row_per_season_week.xlsx"
df = pd.read_excel(file_path)  # 第一行就是表头

# =========================
# 2) 根据文件修改列名（更规范、便于代码引用）
#    Rank top 3  -> rank_top3
#    Rank other  -> rank_other
# =========================
rename_map = {
    "Rank top 3": "rank_top3",
    "Rank other": "rank_other",
}
# 如果列名有多余空格，先 strip 一下再映射
df.columns = [c.strip() if isinstance(c, str) else c for c in df.columns]
df = df.rename(columns=rename_map)

# 你也可以检查一下最终列名：
print("当前列名：", df.columns.tolist())
print(df)

# =========================
# 3) 准备饼图数据（文件只有一行数值）
# =========================
# 取第一行（index=0）作为数值
values = df.loc[0, ["rank_top3", "rank_other"]].astype(float).values
labels = ["Top 3", "Other"]  # 显示更好看（也可换成 df.columns 的名字）

# 如果不是严格和为 1，做一次归一化更稳
s = values.sum()
if s != 0:
    values = values / s

# =========================
# 4) 画图（美化：甜甜圈 + 鲜艳配色 + 阴影 + 引导线 + 突出最大块）
# =========================
plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False

# 鲜艳颜色（你也可以自行换成更喜欢的两色）
colors = ["#30A2FF", "#E8F9A5"]  # 红+绿，够鲜艳
explode = [0.07 if i == int(np.argmax(values)) else 0 for i in range(len(values))]

def autopct_fmt(pct):
    return f"{pct:.1f}%"

P_elim_rank = plt.figure(figsize=(10.5, 7.5), dpi=170)  # 图对象名：P_elim_rank
ax = P_elim_rank.add_subplot(111)
ax.set_facecolor("white")

wedges, texts, autotexts = ax.pie(
    values,
    labels=None,  # 标签我们用外侧注释 + 图例展示
    colors=colors,
    startangle=90,
    counterclock=False,
    explode=explode,
    shadow=True,
    autopct=autopct_fmt,
    pctdistance=0.78,
    wedgeprops=dict(width=0.42, edgecolor="white", linewidth=2.0)  # width<1 => 甜甜圈
)

# 百分比字体更醒目（加描边，视觉更“高级”）
for t in autotexts:
    t.set_fontsize(13)
    t.set_fontweight("bold")
    t.set_color("white")
    t.set_path_effects([patheffects.withStroke(linewidth=3, foreground="black")])

# 中心文字
ax.text(0, 0.02, "P_elim_rank", ha="center", va="center",
        fontsize=18, fontweight="bold")
ax.text(0, -0.10, "Donut Chart", ha="center", va="center",
        fontsize=12, alpha=0.8)

# 外侧标注（引导线 + 标签 + 数值）
for i, w in enumerate(wedges):
    ang = (w.theta2 + w.theta1) / 2.0
    x = np.cos(np.deg2rad(ang))
    y = np.sin(np.deg2rad(ang))

    label_text = f"{labels[i]}: {values[i]:.3f}"
    ax.annotate(
        label_text,
        xy=(x * 0.86, y * 0.86),
        xytext=(x * 1.25, y * 1.25),
        ha="left" if x >= 0 else "right",
        va="center",
        fontsize=12,
        fontweight="bold",
        arrowprops=dict(arrowstyle="-", lw=2, color=colors[i]),
        bbox=dict(boxstyle="round,pad=0.35", fc="white", ec=colors[i], lw=1.8, alpha=0.95)
    )

# 标题 + 图例
ax.set_title("P_elim_rank 分布（Top 3 vs Other）", fontsize=20, fontweight="bold", pad=18)
legend_labels = [f"{labels[i]}  ({values[i]:.1%})" for i in range(len(labels))]
ax.legend(
    wedges, legend_labels,
    loc="lower center",
    bbox_to_anchor=(0.5, -0.05),
    ncol=2,
    frameon=False,
    fontsize=12
)

ax.set_aspect("equal")
plt.tight_layout()

# 保存高清图片
out_png = "P_elim_rank_pie.png"
P_elim_rank.savefig(out_png, dpi=300, bbox_inches="tight")
plt.show()
print("已保存图片：", out_png)
