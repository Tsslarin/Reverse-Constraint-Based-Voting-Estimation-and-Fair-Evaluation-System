import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import statsmodels.formula.api as smf

# ===================== 1) 读取数据（列名必须存在） =====================
# 你原代码使用这个文件名；如果你本地文件名不同，只需要改这里这一行
path = r"partner_celebrities_season_placement_detail_含赛季均值.csv"
df = pd.read_csv(path)

required = [
    "ballroom_partner", "season", "celebrity_name",
    "season_avg_judge_total", "season_avg_estimated_votes_total"
]
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError(f"缺少列：{missing}\n实际列名：{df.columns.tolist()}")

# 转数值（不做归一化！）
df["season_avg_judge_total"] = pd.to_numeric(df["season_avg_judge_total"], errors="coerce")
df["season_avg_estimated_votes_total"] = pd.to_numeric(df["season_avg_estimated_votes_total"], errors="coerce")

# 去掉关键缺失
df = df.dropna(subset=["ballroom_partner", "season"]).copy()

# 输出目录
out_dir = Path("partner_perm_plots")
out_dir.mkdir(parents=True, exist_ok=True)

# ===================== 2) η²(partner -> y)（与你3.4.py一致的效应强度口径） =====================
def eta_squared(cat: pd.Series, y: pd.Series, min_count: int = 2) -> float:
    """
    同你 3.4.py：把样本过少的舞伴合并为 Other，再算组间方差占比 η²
    """
    tmp = pd.DataFrame({"cat": cat, "y": y}).dropna()
    if tmp.empty:
        return np.nan

    vc = tmp["cat"].value_counts()
    rare = vc[vc < min_count].index
    tmp.loc[tmp["cat"].isin(rare), "cat"] = "Other"

    yv = tmp["y"].to_numpy(dtype=float)
    y_mean = yv.mean()
    ss_total = ((yv - y_mean) ** 2).sum()
    if ss_total <= 0:
        return np.nan

    grp = tmp.groupby("cat")["y"]
    means = grp.mean()
    counts = grp.size()
    ss_between = (counts * (means - y_mean) ** 2).sum()
    return float(ss_between / ss_total)

# ===================== 3) 随机效应模型 MixedLM：y ~ 1 + (1|partner) =====================
def eb_shrunken_partner_effects(d: pd.DataFrame, outcome: str, var_u: float, var_e: float) -> pd.DataFrame:
    """
    当 MixedLM 的 random_effects 因 singular 报错时，用 EB shrink 手算舞伴效应（稳定）。
    y_ij = mu + u_j + e_ij
    u_hat_j = B_j * (ybar_j - mu_hat)
    B_j = var_u / (var_u + var_e/n_j)
    """
    g = d.groupby("ballroom_partner")[outcome]
    ybar = g.mean()
    n = g.size().astype(float)
    mu_hat = float(d[outcome].mean())

    if not np.isfinite(var_u) or var_u < 1e-12:
        shrink = pd.Series(0.0, index=ybar.index)
        uhat = pd.Series(0.0, index=ybar.index)
    else:
        shrink = var_u / (var_u + (var_e / n))
        uhat = shrink * (ybar - mu_hat)

    out = pd.DataFrame({
        "ballroom_partner": ybar.index,
        f"partner_effect_{outcome}": uhat.values,
        "shrinkage": shrink.values,
        "n_rows": n.values
    })
    return out

def fit_mixedlm_random_intercept(df_in: pd.DataFrame, outcome: str):
    """
    返回：var_partner, var_resid, icc, partner_effect_table
    注意：若 random_effects 因 singular 报错，则改用 EB shrink 计算舞伴效应表，不中断流程。
    """
    d = df_in.dropna(subset=["ballroom_partner", outcome]).copy()
    if d.empty:
        raise ValueError(f"{outcome} 全为空，无法拟合。")

    md = smf.mixedlm(f"{outcome} ~ 1", data=d, groups=d["ballroom_partner"])

    # 多优化器兜底（更稳）
    last_err = None
    mfit = None
    for method in ["lbfgs", "cg", "nm"]:
        try:
            mfit = md.fit(reml=True, method=method, disp=False)
            break
        except Exception as e:
            last_err = e

    if mfit is None:
        raise RuntimeError(f"MixedLM 拟合失败（已尝试 lbfgs/cg/nm）：{last_err}")

    var_partner = float(mfit.cov_re.iloc[0, 0]) if mfit.cov_re.size else 0.0
    var_resid   = float(mfit.scale) if np.isfinite(mfit.scale) else np.nan
    icc = var_partner / (var_partner + var_resid) if (var_partner + var_resid) > 0 else np.nan

    # 先尝试直接取 random_effects；若 singular 则回退到 EB shrink
    try:
        re = mfit.random_effects
        partner_eff = pd.DataFrame({
            "ballroom_partner": list(re.keys()),
            f"partner_effect_{outcome}": [float(v.values[0]) for v in re.values()]
        })
    except Exception:
        partner_eff = eb_shrunken_partner_effects(d, outcome, var_partner, var_resid)

    # 舞伴带过多少名人（稳健性提示）
    partner_n = (
        d.groupby("ballroom_partner")["celebrity_name"]
         .nunique()
         .rename("n_celebrities")
         .reset_index()
    )
    partner_eff = partner_eff.merge(partner_n, on="ballroom_partner", how="left")

    return var_partner, var_resid, icc, partner_eff

# ===================== 4) 置换检验：赛季内打乱舞伴 =====================
def permute_partner_within_season(df_in: pd.DataFrame, rng: np.random.Generator) -> pd.Series:
    """在每个 season 内打乱 ballroom_partner"""
    return (df_in.groupby("season")["ballroom_partner"]
                 .transform(lambda s: rng.permutation(s.to_numpy())))

def perm_test_eta2(df_in: pd.DataFrame, outcome: str, B: int = 2000, seed: int = 42, min_count: int = 2):
    """
    右尾 p 值：P(eta2_perm >= eta2_true)
    返回：true_eta2, p, perm_vals
    """
    d = df_in.dropna(subset=["ballroom_partner", "season", outcome]).copy()
    rng = np.random.default_rng(seed)

    true_eta2 = eta_squared(d["ballroom_partner"], d[outcome], min_count=min_count)
    perm_vals = []

    for _ in range(B):
        dp = d.copy()
        dp["ballroom_partner"] = permute_partner_within_season(dp, rng)
        perm_vals.append(eta_squared(dp["ballroom_partner"], dp[outcome], min_count=min_count))

    perm_vals = np.array([v for v in perm_vals if np.isfinite(v)], dtype=float)
    p = (np.sum(perm_vals >= true_eta2) + 1) / (len(perm_vals) + 1)
    return true_eta2, p, perm_vals

# ===================== 5) 新增：画“同款置换检验直方图” =====================
def plot_perm_hist(perm_vals: np.ndarray, obs: float, p: float, outcome: str, out_path: Path):
    """
    生成与你截图同款风格的图：
    - 直方图
    - 右侧虚线标 obs eta2
    - 标题两行：Permutation (within season shuffle) / obs eta2=..., p≈...
    - x/y 标签：eta squared (partner -> outcome), count
    """
    fig = plt.figure(figsize=(10, 6), facecolor="white")
    ax = fig.add_subplot(111)

    ax.hist(perm_vals, bins=40, alpha=0.9)
    ax.axvline(obs, linestyle="--", linewidth=2)

    ax.set_xlabel(f"eta squared (partner -> {outcome})")
    ax.set_ylabel("count")
    ax.set_title(f"Permutation (within season shuffle)\nobs eta2={obs:.4f}, p≈{p:.4f}")

    fig.tight_layout()
    fig.savefig(out_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)

# ===================== 6) 运行：两个 outcome 各做一次 + 输出图 =====================
outcomes = ["season_avg_judge_total", "season_avg_estimated_votes_total"]

summary_rows = []

for y in outcomes:
    print("\n" + "=" * 80)
    print(f"Outcome = {y}  （原始值，不归一化）")

    # (A) MixedLM：方差分解 + ICC + 舞伴效应表（random_effects 或 EB shrink）
    var_partner, var_resid, icc, partner_eff = fit_mixedlm_random_intercept(df, y)
    print(f"[MixedLM] var_partner = {var_partner:.6f}")
    print(f"[MixedLM] var_resid   = {var_resid:.6f}")
    print(f"[MixedLM] ICC         = {icc:.4f}")

    out_csv = out_dir / f"partner_effect_{y}.csv"
    partner_eff = partner_eff.sort_values(f"partner_effect_{y}", ascending=False)
    partner_eff.to_csv(out_csv, index=False, encoding="utf-8-sig")
    print("✅ 已输出舞伴效应表：", out_csv)

    # (B) η² + 置换检验（并画出同款直方图）
    true_eta2, p_eta2, perm_vals = perm_test_eta2(df, y, B=2000, seed=42, min_count=2)
    print(f"[Perm η²] true_eta2 = {true_eta2:.4f}, p ≈ {p_eta2:.4f}")

    fig_path = out_dir / f"permutation_eta2_hist_{y}.png"
    plot_perm_hist(perm_vals, true_eta2, p_eta2, y, fig_path)
    print("✅ 已输出置换检验图：", fig_path)

    summary_rows.append({
        "outcome": y,
        "var_partner": var_partner,
        "var_resid": var_resid,
        "ICC": icc,
        "eta2": true_eta2,
        "p_perm_eta2": p_eta2
    })

# 汇总表
summary = pd.DataFrame(summary_rows)
summary_out = out_dir / "partner_effect_summary.csv"
summary.to_csv(summary_out, index=False, encoding="utf-8-sig")
print("\n✅ 已输出汇总表：", summary_out)
print("✅ 全部输出目录：", out_dir.resolve())
