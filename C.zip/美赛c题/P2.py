import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# ===== 1) 读取数据 =====
file_path = "fan_vote2.xlsx"  # 替换为你的文件路径
df = pd.read_excel(file_path)

# 处理合并单元格的NaN值（向下填充）
df[["Season", "Week"]] = df[["Season", "Week"]].ffill()

# 保持原始顺序，重置索引
df = df.reset_index(drop=True)

# ===== 2) 构造分组信息与颜色映射 =====
# 创建 Season+Week 组合分组
df["Group"] = df["Season"].astype(str) + " | " + df["Week"].astype(str)

# 按出现顺序获取唯一分组列表和赛季列表
groups_in_order = df["Group"].drop_duplicates().tolist()
seasons_in_order = df["Season"].drop_duplicates().tolist()

# 为每个分组分配颜色（丰富配色）
cmap = plt.get_cmap("tab20")
group_color = {g: cmap(i % 20) for i, g in enumerate(groups_in_order)}
bar_colors = df["Group"].map(group_color).tolist()

# 准备基础数据
x = np.arange(len(df))
names = df["Name"].astype(str).tolist()
vote_mean = df["Fan_vote_mean"].astype(float).to_numpy()
vote_std = df["Fan_vote_std"].astype(float).to_numpy()

# ===== 3) 计算边界位置与赛季数据区间 =====
# 赛季边界：不同赛季之间的分割点
season_change_idx = np.where(df["Season"].values[:-1] != df["Season"].values[1:])[0]
season_boundaries = (season_change_idx + 0.5).tolist()

# 周边界：不同周之间的分割点
week_change_idx = np.where(df["Group"].values[:-1] != df["Group"].values[1:])[0]
week_boundaries = (week_change_idx + 0.5).tolist()

# 按赛季划分数据区间（用于折线分段绘制，避免重影）
season_data_ranges = []
for season in seasons_in_order:
    season_mask = df["Season"] == season
    season_indices = df[season_mask].index.tolist()
    if season_indices:
        season_data_ranges.append((season_indices[0], season_indices[-1]))

# ===== 4) 初始化图表（关键：只创建一个右轴，解决重影问题） =====
# 设置中文字体
plt.rcParams["font.sans-serif"] = ["SimHei", "Arial Unicode MS", "Noto Sans CJK SC", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

# 增加底部边距（从0.15调整为0.2，确保赛季周次显示更靠下）
fig, ax1 = plt.subplots(figsize=(18, 8), dpi=180, gridspec_kw={"bottom": 0.2})

# --- 绘制柱状图（得票率均值） ---
bars = ax1.bar(
    x, vote_mean,
    color=bar_colors,
    edgecolor="white",
    linewidth=0.8,
    alpha=0.95,
    label="Fan Vote Mean"
)
ax1.set_ylabel("Fan Vote Mean", fontsize=11)
ax1.set_ylim(0, max(vote_mean) * 1.25)

# --- 绘制分段折线图（核心优化：单右轴+浅蓝色） ---
# 只创建一个右轴，解决多次创建导致的重影问题
ax2 = ax1.twinx()
# 折线颜色改为浅蓝色：#87CEEB（天空蓝，透明度0.9）
for start_idx, end_idx in season_data_ranges:
    # 提取当前赛季的x和std数据
    season_x = x[start_idx:end_idx+1]
    season_std = vote_std[start_idx:end_idx+1]
    
    # 绘制当前赛季的折线（每个赛季单独绘制，实现不相连）
    ax2.plot(
        season_x, season_std,
        color="#87CEEB",  # 浅蓝色：天空蓝
        linewidth=2.2,
        marker="o",
        markersize=4.5,
        alpha=0.9,
        label="Fan Vote Std" if start_idx == 0 else ""  # 仅第一个赛季添加图例
    )

# 右轴样式设置（避免重影的关键配置）
ax2.set_ylabel("Fan Vote Std", fontsize=11, color="#87CEEB")
ax2.tick_params(axis="y", colors="#87CEEB")  # 右轴刻度颜色与折线一致
ax2.set_ylim(0, max(vote_std) * 1.35)
ax2.spines["right"].set_color("#87CEEB")  # 右轴边框颜色与折线一致

# ===== 5) 横轴设置（核心：缩小人名字号） =====
ax1.set_xticks(x)
# 人名字号从9缩小到8，增加行间距避免重叠
ax1.set_xticklabels(
    names, 
    rotation=60, 
    ha="right", 
    fontsize=5,  # 人名字号缩小（原9→8）
    linespacing=1.2  # 增加行间距，提升可读性
)

# ===== 6) 绘制边界分隔线 =====
# 赛季边界：深色虚线
for b in season_boundaries:
    ax1.axvline(b, color="#ECF1A3", linestyle="--", linewidth=1.6, alpha=0.9)

# 周边界：浅色细线
for b in week_boundaries:
    ax1.axvline(b, color="#999999", linestyle=":", linewidth=1.0, alpha=0.55)

# ===== 7) 赛季周次显示（核心：位置更靠下） =====
# y坐标从-0.12调整为-0.18，确保显示更靠下，不与人名重叠
for g in groups_in_order:
    group_indices = df.index[df["Group"] == g].to_numpy()
    x_center = (group_indices.min() + group_indices.max()) / 2
    ax1.text(
        x_center, -0.22,  # 位置更靠下（原-0.12→-0.18）
        g,
        ha="center", 
        va="top",
        fontsize=10,
        bbox=dict(boxstyle="round,pad=0.3", facecolor="#F5F5F5", edgecolor="#DDDDDD", alpha=0.8),
        transform=ax1.get_xaxis_transform()  # 基于x轴坐标，位置固定
    )

# ===== 8) 图表美化与布局 =====
# 网格：仅y轴显示，浅色虚线
ax1.grid(axis="y", linestyle="--", alpha=0.25, color="#EEEEEE")

# 图例：合并柱状图和折线图的图例（避免重复）
handles1, labels1 = ax1.get_legend_handles_labels()
handles2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(
    handles1 + handles2, 
    labels1 + labels2, 
    loc="upper left", 
    frameon=True,
    framealpha=0.9,
    fontsize=10
)

# 标题
ax1.set_title(
    "Fan Vote Mean and Std ",
    fontsize=14,
    pad=20
)

# 调整布局，确保所有元素完整显示
plt.tight_layout()
# 保存图片（高DPI保证清晰度）
plt.savefig("fan_vote_bar_line_final.png", bbox_inches="tight", dpi=180)
plt.show()