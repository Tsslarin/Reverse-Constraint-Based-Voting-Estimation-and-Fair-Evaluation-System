import pandas as pd
import numpy as np

# 1) 读取你已有的“差异周明细表”
path = "diff_weeks_elim_details.xlsx"
df = pd.read_excel(path)  # 默认读第一个sheet

# 2) 兼容性检查：必须有这些列（与你之前生成的表一致）
required = [
    "season", "week",
    "elim_by_rank", "rank_method_fan_rank", "rank_method_judge_rank",
    "elim_by_percent", "percent_method_fan_rank", "percent_method_judge_rank",
]
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError(f"表格缺少列：{missing}\n请确认你导出的 diff_weeks_elim_details.xlsx 列名是否一致。")

# 3) n_contestants：优先用表里已有的；没有就用当行最大rank推断
if "n_contestants" in df.columns:
    n = pd.to_numeric(df["n_contestants"], errors="coerce")
else:
    n = df[["rank_method_fan_rank", "rank_method_judge_rank",
            "percent_method_fan_rank", "percent_method_judge_rank"]].max(axis=1)

n = pd.to_numeric(n, errors="coerce").fillna(0).astype(int)

# 4) 计算归一化rank（越接近1越差）
def norm_rank(rank, n):
    rank = pd.to_numeric(rank, errors="coerce")
    # n=1 或 n<=1 时避免除0
    denom = (n - 1).replace(0, np.nan)
    return (rank - 1) / denom

df["rank_fan_norm"] = norm_rank(df["rank_method_fan_rank"], n)
df["rank_judge_norm"] = norm_rank(df["rank_method_judge_rank"], n)
df["percent_fan_norm"] = norm_rank(df["percent_method_fan_rank"], n)
df["percent_judge_norm"] = norm_rank(df["percent_method_judge_rank"], n)

# 5) 粉丝偏向指数：粉丝越差(越大) - 评委越差(越大)
df["fan_bias_index_rank"] = df["rank_fan_norm"] - df["rank_judge_norm"]
df["fan_bias_index_percent"] = df["percent_fan_norm"] - df["percent_judge_norm"]

# 6) 在每个差异周里：哪种方法更偏粉丝（指数更大）
df["more_fan_favoring_method"] = np.where(
    df["fan_bias_index_percent"] > df["fan_bias_index_rank"], "Percent",
    np.where(df["fan_bias_index_percent"] < df["fan_bias_index_rank"], "Rank", "Tie")
)

# 7) 辅助判据（更直观）：谁淘汰了“粉丝排名更差(更大)”的人
df["percent_elim_has_worse_fan_rank"] = df["percent_method_fan_rank"] > df["rank_method_fan_rank"]
df["percent_elim_has_better_judge_rank"] = df["percent_method_judge_rank"] < df["rank_method_judge_rank"]
# “更偏粉丝”的强证据：粉丝更差 AND 评委更好（但仍被淘汰）
df["percent_more_fan_driven_strong"] = df["percent_elim_has_worse_fan_rank"] & df["percent_elim_has_better_judge_rank"]

# 8) 按赛季汇总判断
season_summary = (
    df.groupby("season", as_index=False)
      .agg(
          diff_weeks=("week", "count"),
          mean_fbi_rank=("fan_bias_index_rank", "mean"),
          mean_fbi_percent=("fan_bias_index_percent", "mean"),
          percent_wins=("more_fan_favoring_method", lambda s: (s == "Percent").mean()),
          rank_wins=("more_fan_favoring_method", lambda s: (s == "Rank").mean()),
          tie_rate=("more_fan_favoring_method", lambda s: (s == "Tie").mean()),
          strong_percent_rate=("percent_more_fan_driven_strong", "mean"),
      )
)

# 9) 全局结论（跨所有赛季差异周）
overall = {
    "total_diff_weeks": len(df),
    "mean_fbi_rank": df["fan_bias_index_rank"].mean(),
    "mean_fbi_percent": df["fan_bias_index_percent"].mean(),
    "percent_win_rate": (df["more_fan_favoring_method"] == "Percent").mean(),
    "rank_win_rate": (df["more_fan_favoring_method"] == "Rank").mean(),
    "tie_rate": (df["more_fan_favoring_method"] == "Tie").mean(),
    "strong_percent_rate": df["percent_more_fan_driven_strong"].mean(),
}
overall_df = pd.DataFrame([overall])

# 10) 输出到新Excel（便于你写报告：证据表 + 结论表）
out_xlsx = "fan_bias_comparison_on_diff_weeks.xlsx"
with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
    df.sort_values(["season", "week"]).to_excel(writer, index=False, sheet_name="DiffWeeks_Enriched")
    season_summary.sort_values("season").to_excel(writer, index=False, sheet_name="Season_Summary")
    overall_df.to_excel(writer, index=False, sheet_name="Overall_Summary")

print(f"✅ 已输出：{out_xlsx}")
print("=== Overall Summary ===")
print(overall_df.to_string(index=False))

# 给一个一句话结论（按全局平均FBI）
if overall["mean_fbi_percent"] > overall["mean_fbi_rank"]:
    print("结论倾向：Percent 方法更偏向粉丝投票（在差异周里淘汰者更呈现‘粉丝更差但评委不差’的特征）。")
elif overall["mean_fbi_percent"] < overall["mean_fbi_rank"]:
    print("结论倾向：Rank 方法更偏向粉丝投票。")
else:
    print("结论倾向：两种方法在‘偏向粉丝投票’程度上整体相近。")
