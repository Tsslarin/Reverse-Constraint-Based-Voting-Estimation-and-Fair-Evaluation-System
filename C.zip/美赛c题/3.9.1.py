import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import re
from collections import defaultdict
from matplotlib.colors import ListedColormap

# =========================
# 0) 路径与基本设置
# =========================
in_path = Path("eta2_by_season_week_method.csv")
out_dir = Path("eta2_figs")
out_dir.mkdir(parents=True, exist_ok=True)

# 不筛选 method（rank/percent 混合一起画）
METHOD_FILTER = None  # 保持 None，不需要你改

# =========================
# 1) 视觉设置：浅色、多色（更丰富）热力图 + 图中文字去下划线
# =========================
def no_underscore(s: str) -> str:
    """把图中所有字符串里的 '_' 替换为空格（只影响图中文字，不影响数据列名/文件名）。"""
    return str(s).replace("_", " ")

def make_pastel_multihue_cmap(base_cmap_name="turbo", lighten_factor=0.72, span=(0.08, 0.85), n=256):
    """
    生成“浅色 + 多色渐变”的 colormap：
    - base_cmap_name 用多色渐变（如 'turbo' / 'Spectral' / 'gist_rainbow'）
    - span 截取 colormap 的中间段，避免过暗/过刺眼
    - lighten_factor 与白色混合让整体变浅（越大越浅）
    """
    base = plt.get_cmap(base_cmap_name, n)
    xs = np.linspace(span[0], span[1], n)
    colors = base(xs)
    white = np.ones_like(colors)
    colors[:, :3] = (1 - lighten_factor) * colors[:, :3] + lighten_factor * white[:, :3]
    return ListedColormap(colors)

# ✅ 多色渐变但保持浅色（更“丰富”）
HEATMAP_CMAP = make_pastel_multihue_cmap(
    base_cmap_name="turbo",   # 多色渐变更丰富
    lighten_factor=0.72,      # 让整体足够浅
    span=(0.08, 0.85),        # 截取中间段避免太暗
    n=256
)

# =========================
# 2) 读取数据 + 基础清洗（按“实际列名”自适应）
# =========================
df = pd.read_csv(in_path)

# 去掉 Excel 导出常见的 Unnamed 列
df = df.loc[:, ~df.columns.str.contains(r"^Unnamed", na=False)].copy()

# 必要列检查
for c in ["season", "week"]:
    if c not in df.columns:
        raise ValueError(f"缺少列：{c}，实际列名：{df.columns.tolist()}")

# method 过滤（此处默认不筛选）
if "method" in df.columns and METHOD_FILTER is not None:
    df = df[df["method"].astype(str).str.lower() == str(METHOD_FILTER).lower()].copy()

# season/week 转数值，保证排序正确
df["season"] = pd.to_numeric(df["season"], errors="coerce")
df["week"] = pd.to_numeric(df["week"], errors="coerce")
df = df.dropna(subset=["season", "week"]).copy()
df["season"] = df["season"].astype(int)
df["week"] = df["week"].astype(int)

# 自动识别 eta2 列，并强制转为数值（避免 object 导致 mean 报错）
eta_cols = [c for c in df.columns if str(c).startswith("eta2_")]
if not eta_cols:
    raise ValueError(f"未找到以 'eta2_' 开头的列。当前列名：{df.columns.tolist()}")

for c in eta_cols:
    df[c] = pd.to_numeric(df[c], errors="coerce")

# 自动配对：eta2_<factor>_vote 与 eta2_<factor>_judge
pairs = defaultdict(dict)
for c in eta_cols:
    m = re.match(r"^eta2_(.+)_(vote|judge)$", str(c))
    if m:
        factor, target = m.group(1), m.group(2)
        pairs[factor][target] = c

paired_factors = [f for f in pairs.keys() if "vote" in pairs[f] and "judge" in pairs[f]]
if not paired_factors:
    raise ValueError(
        "没有找到成对的 (eta2_<factor>_vote, eta2_<factor>_judge) 列。\n"
        f"当前 eta2 列：{eta_cols}"
    )

print("[INFO] Detected eta2 factors:", paired_factors)

# =========================
# 3) 统一 eta^2 取值范围（更可比、更美观）
# =========================
all_eta = np.concatenate([df[c].dropna().to_numpy(dtype=float) for c in eta_cols])
if all_eta.size == 0:
    raise ValueError("eta2 全是空值，无法绘图。")

q95 = float(np.nanpercentile(all_eta, 95))
vmin = 0.0
# 让热力图对比更明显：取 95 分位和 0.30 之间较小者，并设下限防止过扁
vmax = min(0.50, q95)
vmax = max(vmax, 0.06)

print(f"[INFO] Using unified eta^2 range: vmin={vmin:.3f}, vmax={vmax:.3f} (q95={q95:.3f})")

# =========================
# 4) 绘图工具函数
# =========================
def save_fig(fig, filename: str):
    out_path = out_dir / filename
    fig.savefig(out_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("✅ saved:", out_path)

def make_heatmap(data: pd.DataFrame, value_col: str, title: str, fname: str):
    piv = data.pivot_table(index="season", columns="week", values=value_col, aggfunc="mean")
    piv = piv.sort_index().sort_index(axis=1)

    fig = plt.figure(figsize=(10, 5), facecolor="white")
    ax = fig.add_subplot(111)

    im = ax.imshow(
        piv.values,
        aspect="auto",
        interpolation="nearest",
        vmin=vmin,
        vmax=vmax,
        origin="lower",
        cmap=HEATMAP_CMAP,     # ✅ 浅色 + 多色（更丰富）
    )

    ax.set_yticks(range(len(piv.index)))
    ax.set_yticklabels(piv.index)
    ax.set_xticks(range(len(piv.columns)))
    ax.set_xticklabels(piv.columns, rotation=90)

    ax.set_xlabel("Week")
    ax.set_ylabel("Season")
    ax.set_title(no_underscore(title))

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("eta^2")

    fig.tight_layout()
    save_fig(fig, fname)

def make_week_trend(data: pd.DataFrame, col_vote: str, col_judge: str, title: str, fname: str):
    g = data.groupby("week")[[col_vote, col_judge]]
    m = g.mean().sort_index()
    s = g.std().sort_index()

    fig = plt.figure(figsize=(10, 4.5), facecolor="white")
    ax = fig.add_subplot(111)

    x = m.index.to_numpy()

    y = m[col_vote].to_numpy()
    ysd = s[col_vote].to_numpy()
    label_vote = no_underscore(col_vote).replace("eta2", "η²")
    ax.plot(x, y, label=label_vote)
    ax.fill_between(x, y-ysd, y+ysd, alpha=0.2)

    y2 = m[col_judge].to_numpy()
    y2sd = s[col_judge].to_numpy()
    label_judge = no_underscore(col_judge).replace("eta2", "η²")
    ax.plot(x, y2, label=label_vote)
    ax.fill_between(x, y2-y2sd, y2+y2sd, alpha=0.2)

    ax.set_xlabel("Week")
    ax.set_ylabel("η²")
    ax.set_title(no_underscore(title))
    ax.set_ylim(vmin, vmax)
    ax.legend()

    fig.tight_layout()
    save_fig(fig, fname)

def make_scatter_vote_vs_judge(data: pd.DataFrame, x_col: str, y_col: str, title: str, fname: str):
    tmp = data[[x_col, y_col]].dropna()

    fig = plt.figure(figsize=(6, 6), facecolor="white")
    ax = fig.add_subplot(111)

    ax.scatter(tmp[x_col], tmp[y_col], alpha=0.6)
    ax.plot([vmin, vmax], [vmin, vmax], linestyle="--")  # y=x 参考线

    ax.set_xlim(vmin, vmax)
    ax.set_ylim(vmin, vmax)
    ax.set_xlabel(no_underscore(x_col))
    ax.set_ylabel(no_underscore(y_col))
    ax.set_title(no_underscore(title))
    ax.set_aspect("equal", adjustable="box")

    fig.tight_layout()
    save_fig(fig, fname)

# =========================
# 5) 批量生成可视化
# =========================
suffix = f"_{METHOD_FILTER}" if METHOD_FILTER is not None else "_all_methods"
suffix_disp = no_underscore(suffix)

for factor in paired_factors:
    vote_col = pairs[factor]["vote"]
    judge_col = pairs[factor]["judge"]
    factor_disp = no_underscore(factor)

    make_heatmap(
        df, vote_col,
        title=f"eta^2 heatmap: {factor_disp} -> vote share {suffix_disp}",
        fname=f"heatmap_{factor}_vote{suffix}.png"
    )

    make_heatmap(
        df, judge_col,
        title=f"eta^2 heatmap: {factor_disp} -> judge share {suffix_disp}",
        fname=f"heatmap_{factor}_judge{suffix}.png"
    )

    make_week_trend(
        df,
        col_vote=vote_col,
        col_judge=judge_col,
        title=f"Weekly mean η² ({factor_disp}) ",
        fname=f"trend_{factor}_weekly_mean{suffix}.png"
    )

    make_scatter_vote_vs_judge(
        df,
        x_col=judge_col,
        y_col=vote_col,
        title=f"{factor_disp}: vote eta^2 vs judge eta^2 {suffix_disp}",
        fname=f"scatter_{factor}_vote_vs_judge{suffix}.png"
    )

print("\n🎉 Done. All figures saved to:", out_dir)
