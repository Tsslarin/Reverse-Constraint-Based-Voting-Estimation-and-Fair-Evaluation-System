import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import re
from matplotlib.colors import ListedColormap

# ========= 路径 =========
in_path = Path("eta2_by_season_week_method.csv")
out_dir = Path("eta2_figs_fullseason")
out_dir.mkdir(parents=True, exist_ok=True)

# ========= 红橙浅色 colormap =========
def make_pastel_orangered_cmap(base_cmap_name="OrRd", lighten_factor=0.68, span=(0.05, 0.78), n=256):
    base = plt.get_cmap(base_cmap_name, n)
    xs = np.linspace(span[0], span[1], n)
    colors = base(xs)
    white = np.ones_like(colors)
    colors[:, :3] = (1 - lighten_factor) * colors[:, :3] + lighten_factor * white[:, :3]
    return ListedColormap(colors)

HEATMAP_CMAP = make_pastel_orangered_cmap(
    base_cmap_name="OrRd",
    lighten_factor=0.68,
    span=(0.05, 0.78),
    n=256
).copy()
HEATMAP_CMAP.set_bad(color="white")  # NaN 显示白色

# ========= 读数据 =========
df = pd.read_csv(in_path)
df = df.loc[:, ~df.columns.astype(str).str.startswith("Unnamed")].copy()

required = {"season", "week", "method"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"缺少必要列 {missing}，当前列名：{list(df.columns)}")

# 基础列类型
df["season"] = pd.to_numeric(df["season"], errors="coerce")
df["week"]   = pd.to_numeric(df["week"], errors="coerce")
df["method"] = df["method"].astype(str)

# 你表格里 industry/country 的列名（如有变化就改这里）
METRICS = {
    "industry": {"vote": "eta2_industry_vote", "judge": "eta2_industry_judge"},
    "country":  {"vote": "eta2_country_vote",  "judge": "eta2_country_judge"},
}

# 检查列存在
for factor, cols in METRICS.items():
    for who, col in cols.items():
        if col not in df.columns:
            raise ValueError(f"找不到列：{col}（factor={factor}, who={who}）。当前列名：{list(df.columns)}")

# ✅ 关键修复：把 eta2 指标列强制转成 numeric，避免 object 导致 mean 报错
eta2_cols = [METRICS[f][w] for f in METRICS for w in METRICS[f]]
for c in eta2_cols:
    # 先去掉可能的逗号/空格等（如果你数据里没有也不影响）
    df[c] = df[c].astype(str).str.replace(",", "", regex=False).str.strip()
    df[c] = pd.to_numeric(df[c], errors="coerce")

# 丢掉 season/week 缺失的行
df = df.dropna(subset=["season", "week"]).copy()
df["season"] = df["season"].astype(int)
df["week"] = df["week"].astype(int)

# ========= 画图函数：全赛季（y=season, x=week） =========
def plot_fullseason_heatmap(sub, value_col, title, out_path, vmax=0.3):
    piv = sub.pivot_table(index="season", columns="week", values=value_col, aggfunc="mean")
    piv = piv.sort_index(axis=0).sort_index(axis=1)

    data = piv.to_numpy(dtype=float)
    data = np.ma.masked_invalid(data)  # NaN -> 白色

    fig, ax = plt.subplots(figsize=(12, max(4, 0.45 * len(piv.index))))
    im = ax.imshow(data, aspect="auto", cmap=HEATMAP_CMAP, vmin=0, vmax=vmax)

    ax.set_xticks(np.arange(piv.shape[1]))
    ax.set_xticklabels([str(w) for w in piv.columns.tolist()], rotation=45, ha="right")
    ax.set_yticks(np.arange(piv.shape[0]))
    ax.set_yticklabels([str(s) for s in piv.index.tolist()])

    ax.set_xlabel("Week")
    ax.set_ylabel("Season")
    ax.set_title(title)

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("η²")

    fig.tight_layout()
    fig.savefig(out_path, dpi=300)
    plt.close(fig)

# ========= 逐 method 输出 =========
methods = sorted(df["method"].dropna().unique())

for method in methods:
    mdf = df[df["method"] == method].copy()
    safe_method = re.sub(r"[^A-Za-z0-9]+", "_", method)

    for factor, cols in METRICS.items():
        for who, col in cols.items():
            title = f"  factor={factor} | target={who} | method={method}"
            out_path = out_dir / f"fullseason_{factor}_{who}_method_{safe_method}.png"
            plot_fullseason_heatmap(mdf, col, title, out_path, vmax=0.3)

print(f"Done. Heatmaps saved to: {out_dir.resolve()}")
