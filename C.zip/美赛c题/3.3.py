import pandas as pd
import re

# ===================== 1) 读取数据（注意：列名来自你的文件） =====================
path = r"2026_MCM_Problem_C_Data.csv"
df = pd.read_csv(path)

# 必要列检查（按你文件实际列名）
required_cols = ["celebrity_name", "ballroom_partner", "season", "placement"]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"缺少必要列：{missing}\n实际列名为：{df.columns.tolist()}")

# ===================== 2) 基础清洗：去空格，避免“名字/舞伴”匹配异常 =====================
def clean_text(x):
    if pd.isna(x):
        return x
    s = str(x).strip()
    s = re.sub(r"\s+", " ", s)  # 连续空格压成一个
    return s

df["celebrity_name"] = df["celebrity_name"].map(clean_text)
df["ballroom_partner"] = df["ballroom_partner"].map(clean_text)

# placement 可能是字符串，转为数值（无法转换的变 NaN）
df["placement"] = pd.to_numeric(df["placement"], errors="coerce")

# ===================== 3) 计算“每个赛季总参赛人数” =====================
# 用 celebrity_name 去重计数：一个赛季多少位名人
season_total = (
    df.groupby("season")["celebrity_name"]
      .nunique()
      .rename("season_total_contestants")
      .reset_index()
)

# ===================== 4) 构造明细表：舞伴-赛季-名人-名次-赛季总人数 =====================
detail = df[["ballroom_partner", "season", "celebrity_name", "placement"]].copy()

# 如果同一 (season, celebrity_name) 在原表中出现重复行（理论上不应有，但这里保险一下），保留第一条
detail = detail.drop_duplicates(subset=["season", "celebrity_name", "ballroom_partner"], keep="first")

# 合并赛季总人数
detail = detail.merge(season_total, on="season", how="left")

# 排序：先舞伴，再赛季，再名次
detail = detail.sort_values(["ballroom_partner", "season", "placement", "celebrity_name"], na_position="last")

# ===================== 5) 可选：做一个“舞伴合作名人清单”的汇总表 =====================
summary = (
    detail.groupby("ballroom_partner")
          .agg(
              n_celebrities=("celebrity_name", "nunique"),
              n_seasons=("season", "nunique"),
              seasons=("season", lambda x: sorted(set(x))),
              celebrities=("celebrity_name", lambda x: sorted(set(x)))
          )
          .reset_index()
          .sort_values(["n_celebrities", "n_seasons"], ascending=False)
)

# ===================== 6) 输出文件 =====================
out_detail_csv = r"partner_celebrities_season_placement_detail.csv"
out_detail_xlsx = r"partner_celebrities_season_placement_detail.xlsx"
out_summary_csv = r"partner_celebrities_summary.csv"
out_summary_xlsx = r"partner_celebrities_summary.xlsx"

detail.to_csv(out_detail_csv, index=False, encoding="utf-8-sig")
detail.to_excel(out_detail_xlsx, index=False)

summary.to_csv(out_summary_csv, index=False, encoding="utf-8-sig")
summary.to_excel(out_summary_xlsx, index=False)

print("✅ 已输出明细：", out_detail_csv, out_detail_xlsx)
print("✅ 已输出汇总：", out_summary_csv, out_summary_xlsx)

# ===================== 7) （可选）示例：查看某个舞伴合作过的所有名人 =====================
# partner_name = "Mark Ballas"  # 改成你关心的舞伴姓名
# print(detail[detail["ballroom_partner"] == partner_name])
