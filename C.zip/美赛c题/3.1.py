import pandas as pd
import re

# ================== 1) 读取两个表 ==================
info_path = r"Q3.xlsx"
votes_path = r"dwts_inferred_fan_votes2.csv"

df_info = pd.read_excel(info_path)
df_votes = pd.read_csv(votes_path)

# ================== 2) 列名（已按你文件的列名写好） ==================
name_col_info = "celebrity_name"     # Q3.xlsx 里的名字列
name_col_votes = "contestant"        # csv 里的名字列

info_cols = [
    "ballroom_partner",
    "celebrity_industry",
    "celebrity_homestate",
    "celebrity_homecountry/region",
    "celebrity_age_during_season",
]

# ================== 3) 名字清洗（避免空格/大小写导致匹配失败） ==================
def normalize_name(x):
    if pd.isna(x):
        return ""
    s = str(x).strip()
    s = re.sub(r"\s+", " ", s)  # 多空格压成1个
    s = s.lower()
    return s

df_info["_key"] = df_info[name_col_info].map(normalize_name)
df_votes["_key"] = df_votes[name_col_votes].map(normalize_name)

# 如果 Q3.xlsx 里出现同名重复，默认保留第一条（会提示）
dup = df_info[df_info["_key"].duplicated(keep=False)].sort_values("_key")
if len(dup) > 0:
    print("⚠️ Q3.xlsx 中存在同名重复（默认保留第一条），重复示例前10条：")
    print(dup[[name_col_info] + info_cols].head(10))

df_info_unique = df_info.drop_duplicates(subset="_key", keep="first")

# ================== 4) 合并：把信息列填进 df_votes ==================
df_merged = df_votes.merge(
    df_info_unique[["_key"] + info_cols],
    on="_key",
    how="left"
)

# ================== 5) 输出：哪些 contestant 没匹配到 ==================
no_match = df_merged[df_merged[info_cols].isna().all(axis=1)][name_col_votes].dropna().unique()
print(f"未匹配到信息的选手数量：{len(no_match)}")
if len(no_match) > 0:
    print("示例（前20个）：", no_match[:20])

# 清理临时列
df_merged.drop(columns=["_key"], inplace=True)

# ================== 6) 保存结果 ==================
out_csv = r"dwts_inferred_fan_votes2_with_info.csv"
out_xlsx = r"dwts_inferred_fan_votes2_with_info.xlsx"

df_merged.to_csv(out_csv, index=False, encoding="utf-8-sig")
df_merged.to_excel(out_xlsx, index=False)

print("✅ 已输出：")
print(out_csv)
print(out_xlsx)
