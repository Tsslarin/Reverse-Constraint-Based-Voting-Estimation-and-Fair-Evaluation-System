import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

# =============== 1) 读入数据 ===============
file_path = r"年龄，职业.xlsx"   # 改成你的实际路径
df = pd.read_excel(file_path)

# 你表格真实列名
AGE_COL = "celebrity_age_during_season"

# 尝试自动识别“赛季列名”
season_candidates = ["season", "Season", "SEASON", "Season #", "season_number", "Season_Number"]
SEASON_COL = next((c for c in season_candidates if c in df.columns), None)

# 如果没有 season，就改为按 industry 画（保证代码可运行）
GROUP_COL = SEASON_COL if SEASON_COL is not None else "celebrity_industry"
if GROUP_COL not in df.columns:
    raise ValueError(
        f"找不到用于分组的列。需要 season 列或 celebrity_industry 列。\n当前列名：{list(df.columns)}"
    )

# 年龄转数值，清理缺失/异常
df[AGE_COL] = pd.to_numeric(df[AGE_COL], errors="coerce")
df = df.dropna(subset=[GROUP_COL, AGE_COL]).copy()

# =============== 2) 计算箱线图统计量（自定义两段填充） ===============
def box_stats(x):
    """返回 (q1, median, q3, low_whisker, high_whisker, fliers)"""
    x = np.asarray(x, dtype=float)
    x = x[~np.isnan(x)]
    if len(x) == 0:
        return None

    q1, med, q3 = np.percentile(x, [25, 50, 75])
    iqr = q3 - q1
    low_bound = q1 - 1.5 * iqr
    high_bound = q3 + 1.5 * iqr

    # whisker：在界内的最小/最大值
    inside = x[(x >= low_bound) & (x <= high_bound)]
    low_whisk = inside.min() if len(inside) else x.min()
    high_whisk = inside.max() if len(inside) else x.max()

    # fliers：离群点
    fliers = x[(x < low_bound) | (x > high_bound)]
    return q1, med, q3, low_whisk, high_whisk, fliers

# 分组排序：如果是 season，按数值升序；否则按名称
if GROUP_COL == SEASON_COL:
    df[GROUP_COL] = pd.to_numeric(df[GROUP_COL], errors="coerce")
    df = df.dropna(subset=[GROUP_COL]).copy()
    df[GROUP_COL] = df[GROUP_COL].astype(int)
    groups = sorted(df[GROUP_COL].unique())
else:
    groups = sorted(df[GROUP_COL].astype(str).unique())

stats = []
for g in groups:
    x = df.loc[df[GROUP_COL] == g, AGE_COL].values
    st = box_stats(x)
    if st is None:
        continue
    stats.append((g,) + st)

# =============== 3) 绘图（复刻示例风格：浅橙色 + 下半更深） ===============
# 颜色（接近你示例图的浅橙/橙）
ORANGE_LIGHT = "#F8D7B5"  # 上半箱体浅橙
ORANGE_DARK  = "#F2A173"  # 下半箱体稍深
LINE_COLOR   = "#5A5A5A"  # 须/中位线/边框
FLIER_COLOR  = "#7A7A7A"  # 离群点灰

fig_w = max(12, 0.45 * len(stats))  # season 多时自动变宽
fig_h = 6.5
fig, ax = plt.subplots(figsize=(fig_w, fig_h))

# 背景与网格
ax.set_facecolor("white")
ax.yaxis.grid(True, linestyle="-", linewidth=0.8, alpha=0.18)
ax.xaxis.grid(False)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

# x 位置
positions = np.arange(1, len(stats) + 1)
box_width = 0.35

# 画每个箱体（两段填充）+ 须 + 离群点
for i, (g, q1, med, q3, wlow, whigh, fliers) in enumerate(stats, start=1):
    # whiskers
    ax.plot([i, i], [wlow, whigh], color=LINE_COLOR, linewidth=1.1, zorder=2)
    cap_w = box_width * 0.9
    ax.plot([i - cap_w/2, i + cap_w/2], [wlow, wlow], color=LINE_COLOR, linewidth=1.1, zorder=2)
    ax.plot([i - cap_w/2, i + cap_w/2], [whigh, whigh], color=LINE_COLOR, linewidth=1.1, zorder=2)

    # box (q1->med) darker
    ax.add_patch(Rectangle(
        (i - box_width/2, q1),
        box_width,
        max(med - q1, 0),
        facecolor=ORANGE_DARK,
        edgecolor="none",
        alpha=0.85,
        zorder=3
    ))

    # box (med->q3) lighter
    ax.add_patch(Rectangle(
        (i - box_width/2, med),
        box_width,
        max(q3 - med, 0),
        facecolor=ORANGE_LIGHT,
        edgecolor="none",
        alpha=0.95,
        zorder=3
    ))

    # box outline (可选：示例图基本没强调边框；想更像就用较淡线)
    ax.add_patch(Rectangle(
        (i - box_width/2, q1),
        box_width,
        max(q3 - q1, 0),
        fill=False,
        edgecolor=LINE_COLOR,
        linewidth=0.9,
        alpha=0.25,
        zorder=4
    ))

    # median line
    ax.plot([i - box_width/2, i + box_width/2], [med, med], color=LINE_COLOR, linewidth=1.2, zorder=5)

    # fliers
    if len(fliers):
        ax.scatter(
            np.full_like(fliers, i, dtype=float),
            fliers,
            s=20,
            color=FLIER_COLOR,
            alpha=0.75,
            zorder=6
        )

# 横向虚线基准（示例图那条虚线：用全体平均年龄）
overall_mean = df[AGE_COL].mean()
ax.axhline(overall_mean, linestyle="--", linewidth=1.1, color=LINE_COLOR, alpha=0.55)

# 轴与标题
ax.set_ylabel("Age")
if GROUP_COL == SEASON_COL:
    ax.set_xlabel("")  # 示例图 x 轴不写 season label，只在上方写 Season #
    ax.set_title("Season ", pad=12)
    ax.set_xticks(positions)
    ax.set_xticklabels([str(g) for (g, *_rest) in stats], fontsize=9)
else:
    ax.set_title("Group #", pad=12)
    ax.set_xticks(positions)
    ax.set_xticklabels([str(g) for (g, *_rest) in stats], rotation=45, ha="right", fontsize=9)

# 合理 y 范围（可按你数据自动）
ymin = max(0, np.floor(df[AGE_COL].min() / 5) * 5)
ymax = np.ceil(df[AGE_COL].max() / 5) * 5
ax.set_ylim(ymin, ymax)

plt.tight_layout()
plt.show()
