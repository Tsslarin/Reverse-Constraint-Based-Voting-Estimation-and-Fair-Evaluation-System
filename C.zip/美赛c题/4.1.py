import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# =========================
# 0) 你需要改的只有这里
# =========================
INPUT_XLSX = r"Q4.xlsx"          # 若不在当前目录，请写绝对路径
SHEET_NAME = "Sheet1"

# λ 敏感性范围（可调整）
LAMBDA_GRID = np.round(np.arange(1.2, 1.81, 0.05), 2)

# w^J 搜索网格（越密越准，但更慢）
WJ_GRID = np.round(np.arange(0.0, 1.0001, 0.01), 2)

# softmax “尖锐程度” β（越大越接近“总是淘汰综合分最低的人”）
BETA = 12.0

# Modified Borda 的凸性参数 γ（>1 强调头部）
GAMMA = 1.5

# 输出文件
OUT_CSV = "lambda_sensitivity_results.csv"
OUT_PNG_WJ = "curve_best_wJ_vs_lambda.png"
OUT_PNG_FIT = "curve_fit_vs_lambda.png"


# =========================
# 1) 读入并只保留“淘汰周”
# =========================
df = pd.read_excel(INPUT_XLSX, sheet_name=SHEET_NAME)

required_cols = ["season", "week", "constraint_type", "eliminated", "contestant",
                 "judge_total", "estimated_votes_total"]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"Q4.xlsx 缺少必要列：{missing}\n当前列名：{df.columns.tolist()}")

# 只用淘汰相关周（排除 final_ranking）
df = df[df["constraint_type"].isin(["elimination", "double_elimination"])].copy()

# 数值化
df["judge_total"] = pd.to_numeric(df["judge_total"], errors="coerce").fillna(0.0)
df["estimated_votes_total"] = pd.to_numeric(df["estimated_votes_total"], errors="coerce").fillna(0.0)

# 清理名字
df["contestant"] = df["contestant"].astype(str).str.strip()
df["eliminated"] = df["eliminated"].astype(str).str.strip()


# =========================
# 2) 工具函数：解析淘汰者名单
# =========================
def parse_eliminated_names(s: str):
    """
    double_elimination 里常见形式：'A & B' 或 'A; B'
    这里做保守分割： & 或 ; 或 ' and ' 或 '/'
    """
    if s is None or (isinstance(s, float) and np.isnan(s)):
        return []
    s = str(s).strip()
    if not s:
        return []
    parts = re.split(r"\s*&\s*|\s*;\s*|\s+and\s+|\s*/\s*", s)
    parts = [p.strip() for p in parts if p.strip()]
    return parts

def safe_div(a, b):
    return a / b if b != 0 else 0.0


# =========================
# 3) 计算当周各人的 S^J 与 F^cap
# =========================
def compute_week_features(dfw: pd.DataFrame, lam: float):
    """
    输入：一个 season-week 的所有选手行
    输出：包含
      - judge_share p^J
      - vote_share  p^V
      - S^J: Modified Borda（凸函数）
      - Fcap: min(p^V, lam * max(p^J))
    """
    out = dfw[["season", "week", "contestant", "judge_total", "estimated_votes_total"]].copy()

    # 只保留有效在场选手（一般都在）
    # 若某周存在全 0 的异常，可让它仍能跑完
    N = len(out)
    if N <= 1:
        # 没法排名，返回空/或最小信息
        out["judge_share"] = 0.0
        out["vote_share"] = 0.0
        out["Sj"] = 0.0
        out["Fcap"] = 0.0
        return out

    # share（占比）
    sumJ = out["judge_total"].sum()
    sumV = out["estimated_votes_total"].sum()
    out["judge_share"] = out["judge_total"].apply(lambda x: safe_div(x, sumJ))
    out["vote_share"] = out["estimated_votes_total"].apply(lambda x: safe_div(x, sumV))

    # judge_rank: 1=最好
    out["judge_rank"] = out["judge_total"].rank(method="average", ascending=False)

    # Modified Borda：把名次转成 0~1，再用 gamma>1 强化头部
    # norm_rank = (N - rank)/(N-1) -> best=1, worst=0
    norm_rank = (N - out["judge_rank"]) / (N - 1)
    out["Sj"] = np.power(norm_rank, GAMMA)

    # Fan cap：不引入 alpha（等价 alpha=1），避免与权重 w 冲突不可识别
    cap_level = lam * out["judge_share"].max()
    out["Fcap"] = out["vote_share"].clip(upper=cap_level)

    return out


# =========================
# 4) 似然：softmax( -beta * u )，k人淘汰用“无放回顺序模型”
# =========================
def softmax_neg_beta_u(u, beta=BETA):
    z = -beta * u
    z = z - np.max(z)  # 防溢出
    expz = np.exp(z)
    return expz / np.sum(expz)

def week_loglik(df_feat: pd.DataFrame, eliminated_list, wJ: float):
    """
    用一个简单但可解释的无放回模型：
    - 先算 u = wJ*Sj + (1-wJ)*Fcap
    - 若淘汰 k 人：按“淘汰者中 u 更低者优先”的顺序逐个从剩余集合中抽取
    """
    if len(eliminated_list) == 0:
        return 0.0

    # 确认淘汰者都在当周名单里；不在就跳过（避免因命名差异导致崩）
    present = set(df_feat["contestant"].tolist())
    eliminated_list = [x for x in eliminated_list if x in present]
    if len(eliminated_list) == 0:
        return 0.0

    df_feat = df_feat.copy()
    df_feat["u"] = wJ * df_feat["Sj"] + (1 - wJ) * df_feat["Fcap"]

    # 确定一个“淘汰顺序”（用淘汰者自身 u 从低到高）
    elim_order = (
        df_feat[df_feat["contestant"].isin(eliminated_list)]
        .sort_values("u", ascending=True)["contestant"]
        .tolist()
    )

    ll = 0.0
    remaining = df_feat.copy()

    for name in elim_order:
        probs = softmax_neg_beta_u(remaining["u"].values, beta=BETA)
        remaining = remaining.reset_index(drop=True)

        idx = remaining.index[remaining["contestant"] == name].tolist()
        if not idx:
            continue
        idx = idx[0]
        p = probs[idx]
        ll += np.log(max(p, 1e-15))  # 防 log(0)

        # 无放回：移除该淘汰者
        remaining = remaining[remaining["contestant"] != name].copy()

    return float(ll)


# =========================
# 5) 给定 λ，估计最优 w^J（最大化总loglik）
# =========================
def fit_wJ_for_lambda(df_all: pd.DataFrame, lam: float):
    # 预先把每周特征算好，避免在 wJ 网格里重复计算
    groups = []
    for (s, w), dfw in df_all.groupby(["season", "week"]):
        elim_str = dfw["eliminated"].iloc[0]
        eliminated_list = parse_eliminated_names(elim_str)
        feat = compute_week_features(dfw, lam)
        groups.append((feat, eliminated_list))

    best = {"wJ": None, "loglik": -np.inf}
    for wJ in WJ_GRID:
        total_ll = 0.0
        for feat, eliminated_list in groups:
            total_ll += week_loglik(feat, eliminated_list, wJ)
        if total_ll > best["loglik"]:
            best = {"wJ": float(wJ), "loglik": float(total_ll)}

    # 计算一个更直观的“命中率”：按 u 最低的k人预测淘汰，与真实淘汰集合比
    # （仅用于展示，不参与MLE）
    hit, total = 0, 0
    for feat, eliminated_list in groups:
        if len(eliminated_list) == 0:
            continue

        present = set(feat["contestant"])
        eliminated_list = [x for x in eliminated_list if x in present]
        if len(eliminated_list) == 0:
            continue

        feat = feat.copy()
        feat["u"] = best["wJ"] * feat["Sj"] + (1 - best["wJ"]) * feat["Fcap"]

        k = len(eliminated_list)
        pred = set(feat.sort_values("u", ascending=True).head(k)["contestant"].tolist())
        true = set(eliminated_list)

        # 集合完全一致算命中
        hit += int(pred == true)
        total += 1

    best["week_hit_rate"] = float(hit / total) if total > 0 else np.nan
    best["n_weeks_used"] = int(total)
    return best


# =========================
# 6) λ 敏感性分析主循环
# =========================
results = []
for lam in LAMBDA_GRID:
    best = fit_wJ_for_lambda(df, lam)
    results.append({
        "lambda": float(lam),
        "best_wJ": best["wJ"],
        "best_loglik": best["loglik"],
        "week_hit_rate": best["week_hit_rate"],
        "n_weeks_used": best["n_weeks_used"]
    })
    print(f"lambda={lam:.2f} -> best_wJ={best['wJ']:.2f}, loglik={best['loglik']:.2f}, hit={best['week_hit_rate']:.3f}")

res = pd.DataFrame(results)
res.to_csv(OUT_CSV, index=False, encoding="utf-8-sig")

# 全局最优（在 λ 网格里选 loglik 最大者）
best_overall = res.loc[res["best_loglik"].idxmax()].to_dict()
print("\n=== Overall Best (within lambda grid) ===")
print(best_overall)


# =========================
# 7) 画敏感性曲线
# =========================
plt.figure()
plt.plot(res["lambda"], res["best_wJ"], marker="o",color="blue")
plt.xlabel("lambda")
plt.ylabel("best wJ")
plt.title("Sensitivity: best wj vs lambda")
plt.grid(True, alpha=0.3)
plt.savefig(OUT_PNG_WJ, dpi=200, bbox_inches="tight")
plt.close()

plt.figure()
plt.plot(res["lambda"], res["best_loglik"], marker="o", label="best log-likelihood",color="blue")
plt.xlabel("lambda")
plt.ylabel("best log-likelihood")
plt.title("Fit quality vs lambda")
plt.grid(True, alpha=0.3)

# 也把命中率画在同一张图（第二纵轴）更直观
ax = plt.gca()
ax2 = ax.twinx()
ax2.plot(res["lambda"], res["week_hit_rate"], marker="s", linestyle="--",color="blue")
ax2.set_ylabel("weekly exact-hit rate")

plt.savefig(OUT_PNG_FIT, dpi=200, bbox_inches="tight")
plt.close()

print("\nSaved:")
print(" -", OUT_CSV)
print(" -", OUT_PNG_WJ)
print(" -", OUT_PNG_FIT)
