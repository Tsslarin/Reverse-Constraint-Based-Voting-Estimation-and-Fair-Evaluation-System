import pandas as pd
import matplotlib.pyplot as plt

# 1) 读数据
path = "lambda_sensitivity_results.csv"
df = pd.read_csv(path)

# 2) 按 lambda 排序
df = df.sort_values("lambda")

# 3) 同一张图 + 双y轴
fig, ax1 = plt.subplots(figsize=(9, 5))

# 左轴：best_loglik
l1, = ax1.plot(
    df["lambda"], df["best loglik"],
    color="blue", linestyle="-", marker="o", linewidth=2,
    label="best loglik"
)
ax1.set_xlabel("lambda")
ax1.set_ylabel("best loglik", color="blue")
ax1.tick_params(axis="y", labelcolor="blue")
ax1.grid(True, linestyle="--", alpha=0.4)

# 右轴：准确率
ax2 = ax1.twinx()
l2, = ax2.plot(
    df["lambda"], df["accuracy"],
    color="blue", linestyle="--", marker="s", linewidth=2,
    label="accuracy"
)
ax2.set_ylabel("accuracy", color="blue")
ax2.tick_params(axis="y", labelcolor="blue")

# —— 图例放到图外上方（不与折线重合）——
lines = [l1, l2]
labels = [ln.get_label() for ln in lines]
fig.legend(
    lines, labels,
    loc="upper center",
    bbox_to_anchor=(0.5, 0.2),  # 图外上方
    ncol=2,
    frameon=True
)

plt.title("best loglik and accuracy vs lambda")
plt.tight_layout(rect=[0, 0, 1, 0.92])  # 给顶部图例留空间
plt.show()

# 如需保存：
# fig.savefig("lambda_dual_axis.png", dpi=300, bbox_inches="tight")
