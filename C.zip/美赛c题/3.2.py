import pandas as pd
import numpy as np

# ===================== 1) 读取数据（按你文件列名） =====================
path = r"dwts_with_week_normalized_shares.csv"
df = pd.read_csv(path)

# 必要列检查
required_cols = [
    "season", "week", "method",
    "celebrity_industry", "celebrity_homecountry/region",
    "vote_share", "judge_share"
]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"缺少必要列：{missing}\n实际列名为：{df.columns.tolist()}")

# ===================== 2) 相关比 η² 函数 =====================
def eta_squared(cat: pd.Series, y: pd.Series, min_count: int = 2) -> float:
    """
    相关比 η²（Correlation Ratio squared）
    cat: 类别变量（行业/国籍）
    y: 连续变量（vote_share/judge_share）
    min_count: 组内样本太少的类别合并为 'Other' 的阈值（建议>=2，避免K=N导致不稳定）
    """
    tmp = pd.DataFrame({"cat": cat, "y": y}).dropna()
    if tmp.empty:
        return np.nan

    # 合并稀有类别（在当前 season-week-method 子样本内做）
    if min_count is not None and min_count > 1:
        vc = tmp["cat"].value_counts(dropna=False)
        rare = vc[vc < min_count].index
        tmp.loc[tmp["cat"].isin(rare), "cat"] = "Other"

    y_vals = tmp["y"].astype(float).to_numpy()
    y_mean = y_vals.mean()
    ss_total = ((y_vals - y_mean) ** 2).sum()
    if ss_total <= 0:
        # 所有y完全相同（方差为0），η²无意义（可认为0或NaN，这里给NaN）
        return np.nan

    grp = tmp.groupby("cat")["y"]
    means = grp.mean()
    counts = grp.size()

    ss_between = (counts * (means - y_mean) ** 2).sum()
    return float(ss_between / ss_total)

def eta_squared_adj(cat: pd.Series, y: pd.Series, min_count: int = 2) -> float:
    """
    调整后的 η²（可选，更稳健，类似 adjusted R²）
    """
    tmp = pd.DataFrame({"cat": cat, "y": y}).dropna()
    if tmp.empty:
        return np.nan

    if min_count is not None and min_count > 1:
        vc = tmp["cat"].value_counts(dropna=False)
        rare = vc[vc < min_count].index
        tmp.loc[tmp["cat"].isin(rare), "cat"] = "Other"

    y_vals = tmp["y"].astype(float).to_numpy()
    N = len(y_vals)
    K = tmp["cat"].nunique(dropna=True)
    if N <= 1 or K <= 1 or N <= K:
        return np.nan

    y_mean = y_vals.mean()
    ss_total = ((y_vals - y_mean) ** 2).sum()
    if ss_total <= 0:
        return np.nan

    # 组内平方和
    ss_within = tmp.groupby("cat").apply(
        lambda g: ((g["y"].astype(float) - g["y"].astype(float).mean()) ** 2).sum()
    ).sum()

    # adjusted eta^2
    eta2_adj = 1.0 - (ss_within / (N - K)) / (ss_total / (N - 1))
    return float(eta2_adj)

# ===================== 3) 按 season-week-method 做 η² 计算 =====================
group_cols = ["season", "week", "method"]

results = []
for (season, week, method), g in df.groupby(group_cols, dropna=False):
    row = {
        "season": season,
        "week": week,
        "method": method,
        "n_rows": len(g),
        "n_contestants": g["contestant"].nunique() if "contestant" in g.columns else np.nan
    }

    # 行业
    row["k_industry"] = g["celebrity_industry"].dropna().nunique()
    row["eta2_industry_vote"]  = eta_squared(g["celebrity_industry"], g["vote_share"], min_count=2)
    row["eta2_industry_judge"] = eta_squared(g["celebrity_industry"], g["judge_share"], min_count=2)
    row["eta2adj_industry_vote"]  = eta_squared_adj(g["celebrity_industry"], g["vote_share"], min_count=2)
    row["eta2adj_industry_judge"] = eta_squared_adj(g["celebrity_industry"], g["judge_share"], min_count=2)

    # 国籍/地区
    row["k_country_region"] = g["celebrity_homecountry/region"].dropna().nunique()
    row["eta2_country_vote"]  = eta_squared(g["celebrity_homecountry/region"], g["vote_share"], min_count=2)
    row["eta2_country_judge"] = eta_squared(g["celebrity_homecountry/region"], g["judge_share"], min_count=2)
    row["eta2adj_country_vote"]  = eta_squared_adj(g["celebrity_homecountry/region"], g["vote_share"], min_count=2)
    row["eta2adj_country_judge"] = eta_squared_adj(g["celebrity_homecountry/region"], g["judge_share"], min_count=2)

    results.append(row)

res_df = pd.DataFrame(results).sort_values(["season", "week", "method"]).reset_index(drop=True)

# ===================== 4) 保存输出 =====================
out_csv = r"eta2_by_season_week_method.csv"
out_xlsx = r"eta2_by_season_week_method.xlsx"

res_df.to_csv(out_csv, index=False, encoding="utf-8-sig")
res_df.to_excel(out_xlsx, index=False)

print("✅ 已输出：")
print(out_csv)
print(out_xlsx)

# （可选）快速查看前几行
print(res_df.head(10))
