import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import re
from matplotlib.colors import ListedColormap

# =========================
# 0) 路径与基本设置
# =========================
in_path = Path("eta2_by_season_week_method.csv")   # 输入表
out_dir = Path("eta2_figs")                        # 输出图片目录
out_dir.mkdir(parents=True, exist_ok=True)

# =========================
# 1) 视觉设置：红橙浅色热力图
# =========================
def make_pastel_orangered_cmap(base_cmap_name="OrRd", lighten_factor=0.68, span=(0.05, 0.9), n=256):
    """
    生成“红橙色 + 浅色”的顺序 colormap（适合热力图）
    """
    base = plt.get_cmap(base_cmap_name, n)
    xs = np.linspace(span[0], span[1], n)
    colors = base(xs)
    white = np.ones_like(colors)
    colors[:, :3] = (1 - lighten_factor) * colors[:, :3] + lighten_factor * white[:, :3]
    return ListedColormap(colors)

HEATMAP_CMAP = make_pastel_orangered_cmap(
    base_cmap_name="OrRd",
    lighten_factor=0.68,   # 想更浅可调大到 0.75
    span=(0.05, 0.78),     # 想更浅可把右端调小到 0.70
    n=256
)

def pretty_metric_name(metric: str) -> str:
    """
    把列名如 'eta2_industry_vote' 显示成 'industry vote'
    """
    s = str(metric)
    s = s.replace("eta2_", "")
    s = s.replace("_", " ")
    return s

# =========================
# 2) 读取数据（按你表格真实列名：season/week/method + 多个 eta2_xxx 列）
# =========================
df = pd.read_csv(in_path)

# 去掉 Unnamed 之类的空列
df = df.loc[:, ~df.columns.astype(str).str.startswith("Unnamed")].copy()

required = {"season", "week", "method"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"缺少必要列 {missing}，当前列名为：{list(df.columns)}")

# eta2 指标列（你表里是宽表：每个指标一个列）
eta2_cols = [c for c in df.columns if str(c).startswith("eta2_")]
if not eta2_cols:
    raise ValueError("未找到任何以 'eta2_' 开头的列。请检查 CSV 列名。")

# 类型处理
df["season"] = pd.to_numeric(df["season"], errors="coerce").astype("Int64")
df["week"] = pd.to_numeric(df["week"], errors="coerce").astype("Int64")
df["method"] = df["method"].astype(str)

# 把宽表转长表：season/week/method/metric/eta2
long = df.melt(
    id_vars=["season", "week", "method"],
    value_vars=eta2_cols,
    var_name="metric",
    value_name="eta2"
)
long["eta2"] = pd.to_numeric(long["eta2"], errors="coerce")
long = long.dropna(subset=["season", "week", "method", "metric", "eta2"]).copy()

# =========================
# 3) 生成热力图：每个 season×method 一张（行=eta2指标，列=week）
# =========================
seasons = sorted(long["season"].dropna().unique())
methods = sorted(long["method"].dropna().unique())

for season in seasons:
    sdf = long[long["season"] == season].copy()
    for method in methods:
        msdf = sdf[sdf["method"] == method].copy()
        if msdf.empty:
            continue

        piv = msdf.pivot_table(index="metric", columns="week", values="eta2", aggfunc="mean")
        piv = piv.sort_index(axis=0).sort_index(axis=1)

        # 画布高度随指标数量自适应
        fig_h = max(3.8, 0.8 * len(piv.index))
        fig, ax = plt.subplots(figsize=(12, fig_h))

        im = ax.imshow(piv.values, aspect="auto", cmap=HEATMAP_CMAP, vmin=0, vmax=0.3)

        # x 轴（week）
        ax.set_xticks(np.arange(piv.shape[1]))
        ax.set_xticklabels([str(w) for w in piv.columns.tolist()], rotation=45, ha="right")

        # y 轴（metric）
        ax.set_yticks(np.arange(piv.shape[0]))
        ax.set_yticklabels([pretty_metric_name(m) for m in piv.index.tolist()])

        ax.set_xlabel("Week")
        ax.set_ylabel("η² metric")
        ax.set_title(f"Season {int(season)} | Method: {method}")

        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label("η²")

        fig.tight_layout()

        safe_method = re.sub(r"[^A-Za-z0-9]+", "_", method)
        out_path = out_dir / f"heatmap_season_{int(season)}_method_{safe_method}.png"
        fig.savefig(out_path, dpi=300)
        plt.close(fig)

print(f"Done. Figures saved to: {out_dir.resolve()}")
