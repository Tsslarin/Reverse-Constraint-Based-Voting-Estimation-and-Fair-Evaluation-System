import os
import re
import pandas as pd

# ========== 配置 ==========
input_csv = "2026_MCM_Problem_C_Data.csv"
output_dir = "split_by_quarter_excels"
quarter_col_index = 6  # 第7列（从0开始数）

os.makedirs(output_dir, exist_ok=True)

# ========== 读取CSV ==========
# 默认读取：让pandas自动推断类型（有助于数字写成数字）
df = pd.read_csv(input_csv)

# 取第7列作为季度列（不假设列名）
quarter_series = df.iloc[:, quarter_col_index]

# ========== 将“全列可转成数字”的object列转为真正数字 ==========
def convert_object_column_to_numeric_if_possible(s: pd.Series) -> pd.Series:
    """
    仅当该列所有非空值都可以转成数字时才转换，以避免“半数字半文本”的列被破坏。
    转换后优先使用 Int64（可空整数），否则用 float。
    """
    if s.dtype != "object":
        return s

    # 先把字符串两端空格去掉（不改变内容语义；仅用于判断是否可转数字）
    s_stripped = s.map(lambda x: x.strip() if isinstance(x, str) else x)

    numeric = pd.to_numeric(s_stripped, errors="coerce")

    # 只有当所有非空值都能转成数字，才整列转换
    non_null_mask = s_stripped.notna()
    if numeric[non_null_mask].notna().all():
        # 判断是否全是整数
        numeric_non_na = numeric.dropna()
        if len(numeric_non_na) > 0 and (numeric_non_na % 1 == 0).all():
            return numeric.astype("Int64")  # 可空整数，写入Excel会是数字
        else:
            return numeric.astype("float64")
    return s  # 保持原样（避免改变数据）

for col in df.columns:
    df[col] = convert_object_column_to_numeric_if_possible(df[col])

# ========== 文件名安全化 ==========
def safe_filename(name: str) -> str:
    name = str(name)
    name = name.strip()
    # 替换掉不适合做文件名的字符
    name = re.sub(r'[\\/:*?"<>|]+', "_", name)
    name = re.sub(r"\s+", "_", name)
    return name if name else "EMPTY"

# ========== 按季度拆分导出 ==========
# 保持原始行顺序：不排序
quarters = quarter_series.dropna().unique()

for q in quarters:
    part = df[quarter_series == q].copy()

    out_path = os.path.join(output_dir, f"quarter_{safe_filename(q)}.xlsx")
    # 写入Excel：保留列名；数字会以数字类型写入（非文本）
    part.to_excel(out_path, index=False, engine="openpyxl")

print(f"Done! 输出目录：{output_dir}")
print("生成的文件：")
for fn in sorted(os.listdir(output_dir)):
    print(" -", fn)
