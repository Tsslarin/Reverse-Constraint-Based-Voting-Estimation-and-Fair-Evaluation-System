import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# =========================
# 0) 读取数据
# =========================
in_path = Path("舞伴对评审和粉丝.csv")
out_dir = Path("partner_effect_figs")
out_dir.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(in_path)

# =========================
# 1) 基于列名做健壮检查与清洗
# =========================
# ICC 列（优先完全匹配 'ICC'，否则找包含 'icc' 的）
icc_candidates = [c for c in df.columns if str(c).strip().lower() == "icc"]
if not icc_candidates:
    icc_candidates = [c for c in df.columns if "icc" in str(c).strip().lower()]
if not icc_candidates:
    raise ValueError(f"找不到 ICC 列。当前列名：{df.columns.tolist()}")
icc_col = icc_candidates[0]

# outcome 列（找常见名字；找不到就用第一列）
outcome_candidates = [c for c in df.columns if str(c).strip().lower() in ["outcome", "target", "y"]]
outcome_col = outcome_candidates[0] if outcome_candidates else df.columns[0]

# 数值化 ICC
df[icc_col] = pd.to_numeric(df[icc_col], errors="coerce")
df = df.dropna(subset=[icc_col]).copy()

# outcome 清理：下划线替换为空格
df[outcome_col] = df[outcome_col].astype(str).str.strip().str.replace("_", " ")

# 按 ICC 从大到小排
df = df.sort_values(icc_col, ascending=False).reset_index(drop=True)

# =========================
# 2) 画 ICC 图（含 0.2 基准线）
# =========================
baseline = 0.2
n = len(df)

fig = plt.figure(figsize=(7, 4.5), facecolor="white")
ax = fig.add_subplot(111)

# ✅ 0.2 基准线（虚线）
ax.axhline(baseline, linestyle="--", linewidth=1.5, label="baseline 0.2")

if n == 1:
    icc_val = float(df.loc[0, icc_col])
    ax.scatter([1], [icc_val], zorder=3)
    ax.set_xlim(0.5, 1.5)
    ax.set_xticks([1])
    ax.set_xticklabels(["partner ICC"])
    ax.text(1, icc_val, f"  {icc_val:.3f}", va="center", fontsize=10)
else:
    x = np.arange(n)
    y = df[icc_col].to_numpy(dtype=float)

    ax.scatter(x, y, zorder=3)

    ax.set_xticks(x)
    ax.set_xticklabels(df[outcome_col].tolist(), rotation=20, ha="right")

    # 标注数值
    for i, v in enumerate(y):
        if np.isfinite(v):
            ax.text(i, v, f"  {v:.3f}", va="center", fontsize=9)

ax.set_ylabel("ICC")
ax.set_title("Partner effect size (ICC)")
ymax = float(df[icc_col].max())
ax.set_ylim(0, min(1.0, max(0.6, ymax + 0.08)))  # 自动留一点上边距
ax.grid(axis="y", alpha=0.25)
ax.legend(loc="upper right")

fig.tight_layout()

out_path = out_dir / "icc_plot.png"
fig.savefig(out_path, dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)

print("✅ ICC 图已保存：", out_path.resolve())
