import os
import re
import pandas as pd
import numpy as np

# =========================
# 0) 文件路径设置（按需修改）
# =========================
VOTES_PATH = "dwts_inferred_fan_votes - 第二问·.csv"   # 你的每周评委分+粉丝票文件
OFFICIAL_PATH = "2026_MCM_Problem_C_Data.csv"         # 可选：对照真实冠军
OUT_EXCEL = "ALL_seasons_rank_vs_percent_simulation.xlsx"
OUT_CONFLICT_CSV = "conflict_season_week.csv"


# =========================
# 1) 统一列名映射 + 清洗
# =========================
def resolve_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    自动把列名映射到标准列：
    season, week, contestant, judge_total, estimated_votes_total
    若 judge_total 不存在，会尝试从 judge 打分列求和。
    """
    cols = df.columns.astype(str).tolist()

    def pick_col(candidates):
        for c in candidates:
            if c in cols:
                return c
        return None

    season_col = pick_col(["season"])
    week_col = pick_col(["week"])
    contestant_col = pick_col(["contestant", "celebrity_name", "celebrity", "name"])
    vote_col = pick_col(["estimated_votes_total", "inferred_fan_votes", "fan_votes_est", "fan_votes", "votes_estimated"])
    judge_total_col = pick_col(["judge_total", "judges_total", "total_judge_score", "judge_score_total", "judge_score"])

    if season_col is None or week_col is None or contestant_col is None:
        raise ValueError(
            f"文件缺少关键列。至少需要 season/week/contestant(或celebrity_name)。\n当前列名：{cols}"
        )

    # 若没有 judge_total，尝试由“像评委打分”的列求和
    if judge_total_col is None:
        judge_score_like = []
        for c in cols:
            cl = c.lower()
            if ("judge" in cl and "score" in cl) or re.fullmatch(r"judge\d+_score", cl):
                judge_score_like.append(c)
        if len(judge_score_like) == 0:
            raise ValueError(
                "找不到 judge_total 列，也无法从 judge*score 列推断评审总分。\n"
                f"当前列名：{cols}"
            )
        df["judge_total"] = df[judge_score_like].apply(pd.to_numeric, errors="coerce").sum(axis=1)
        judge_total_col = "judge_total"

    if vote_col is None:
        raise ValueError(
            "找不到粉丝投票列。请确保包含 estimated_votes_total（或 inferred_fan_votes / fan_votes_est 等）。\n"
            f"当前列名：{cols}"
        )

    out = df.rename(
        columns={
            season_col: "season",
            week_col: "week",
            contestant_col: "contestant",
            judge_total_col: "judge_total",
            vote_col: "estimated_votes_total",
        }
    ).copy()

    # 去掉 Unnamed 列
    out = out.loc[:, ~out.columns.astype(str).str.contains(r"^Unnamed")].copy()

    # 类型清洗
    out["season"] = pd.to_numeric(out["season"], errors="coerce")
    out["week"] = pd.to_numeric(out["week"], errors="coerce")
    out["contestant"] = out["contestant"].astype(str).str.strip()
    out["judge_total"] = pd.to_numeric(out["judge_total"], errors="coerce")
    out["estimated_votes_total"] = pd.to_numeric(out["estimated_votes_total"], errors="coerce")

    # 丢掉关键字段缺失（票数允许 NaN，后面会用 is_no_vote_week 处理）
    out = out.dropna(subset=["season", "week", "contestant", "judge_total"]).copy()

    out["season"] = out["season"].astype(int)
    out["week"] = out["week"].astype(int)

    # 同一选手同一周重复行：汇总成一行
    out = (
        out.groupby(["season", "week", "contestant"], as_index=False)
        .agg({"judge_total": "sum", "estimated_votes_total": "sum"})
    )

    return out


# =========================
# 2) 判断“无淘汰周/无投票周”：票数缺失或全 0 => 跳过
# =========================
def is_no_vote_week(g: pd.DataFrame) -> bool:
    """
    你的数据特点：没有人淘汰的周缺少粉丝投票
    => votes 全 NaN 或（NaN 当 0 后）全 0，就认为该周应跳过
    """
    s = g["estimated_votes_total"]
    if s.isna().all():
        return True
    if (s.fillna(0) == 0).all():
        return True
    return False


# =========================
# 3) 单周：计算 Rank & Percent 两种合票排序
# =========================
def compute_week_scores(g: pd.DataFrame) -> pd.DataFrame:
    gg = g.copy()

    # 注意：这里不把“无投票周”送进来（外面已跳过）
    # 但有时个别选手票数缺失，这里将缺失按 0 处理，避免 rank/percent 出 NaN
    gg["judge_total_f"] = gg["judge_total"].fillna(0.0)
    gg["votes_f"] = gg["estimated_votes_total"].fillna(0.0)

    # --- Rank 法 ---
    gg["judge_rank"] = gg["judge_total_f"].rank(ascending=False, method="min")
    gg["fan_rank"] = gg["votes_f"].rank(ascending=False, method="min")
    gg["sum_ranks"] = gg["judge_rank"] + gg["fan_rank"]

    # tie-break：fan 更好优先，再 judge，再名字
    gg = gg.sort_values(
        by=["sum_ranks", "fan_rank", "judge_rank", "contestant"],
        ascending=[True, True, True, True]
    ).copy()
    gg["overall_rank_rankmethod"] = np.arange(1, len(gg) + 1)

    # --- Percent 法 ---
    sum_j = gg["judge_total_f"].sum()
    sum_v = gg["votes_f"].sum()

    if sum_j <= 0 or sum_v <= 0:
        # 极端兜底：无法算占比
        gg["judge_percent"] = np.nan
        gg["fan_percent"] = np.nan
        gg["combined_percent"] = np.nan
        gg = gg.sort_values(by=["votes_f", "judge_total_f", "contestant"], ascending=[False, False, True]).copy()
        gg["overall_rank_percent"] = np.arange(1, len(gg) + 1)
        return gg

    gg["judge_percent"] = gg["judge_total_f"] / sum_j
    gg["fan_percent"] = gg["votes_f"] / sum_v
    gg["combined_percent"] = gg["judge_percent"] + gg["fan_percent"]

    gg = gg.sort_values(
        by=["combined_percent", "fan_percent", "judge_percent", "contestant"],
        ascending=[False, False, False, True]
    ).copy()
    gg["overall_rank_percent"] = np.arange(1, len(gg) + 1)

    return gg


# =========================
# 4) 模拟一个赛季：只用“有投票的周”（淘汰周）来推进
# =========================
def simulate_season(all_df: pd.DataFrame, season: int):
    d = all_df[all_df["season"] == season].copy()
    if d.empty:
        return None, None, None, None

    week_groups = {w: g for w, g in d.groupby("week", sort=True)}

    # ✅关键修改：只保留“有投票(=淘汰周)”的周；没有人淘汰的周会被跳过
    vote_weeks = []
    for w in sorted(week_groups.keys()):
        if not is_no_vote_week(week_groups[w]):
            vote_weeks.append(w)

    # 至少两个淘汰周，才能用人数差推断淘汰人数
    if len(vote_weeks) < 2:
        return None, None, None, None

    # 每个淘汰周的人数
    n_by_week = {w: week_groups[w]["contestant"].nunique() for w in vote_weeks}

    weekly_rows = []
    detail_rows = []
    champ_info = None

    for i, w in enumerate(vote_weeks):
        g = week_groups[w].copy()
        g_scored = compute_week_scores(g)
        g_scored["season"] = season
        g_scored["week"] = w

        n_now = int(n_by_week[w])

        # ✅淘汰人数：用“相邻两个淘汰周的人数差”推断
        # 这样相当于自动跨越所有无淘汰周（因为它们在 vote_weeks 里不存在）
        if i < len(vote_weeks) - 1:
            n_next = int(n_by_week[vote_weeks[i + 1]])
            k = max(n_now - n_next, 0)
        else:
            k = 0  # 最后一投票周用于判冠军

        # 淘汰名单
        elim_rank = []
        elim_pct = []
        if k > 0:
            worst_rank = g_scored.sort_values("overall_rank_rankmethod", ascending=False).head(k)
            worst_pct = g_scored.sort_values("overall_rank_percent", ascending=False).head(k)
            elim_rank = worst_rank["contestant"].astype(str).tolist()
            elim_pct = worst_pct["contestant"].astype(str).tolist()

        g_scored["elim_by_rank"] = g_scored["contestant"].isin(elim_rank)
        g_scored["elim_by_percent"] = g_scored["contestant"].isin(elim_pct)

        conflict = (k > 0) and (set(elim_rank) != set(elim_pct))

        weekly_rows.append({
            "season": season,
            "week": w,
            "n_contestants": n_now,
            "k_elims_inferred": k,
            "eliminated_by_rank": ", ".join(elim_rank) if elim_rank else "-",
            "eliminated_by_percent": ", ".join(elim_pct) if elim_pct else "-",
            "conflict": conflict
        })

        detail_rows.append(g_scored)

        # 冠军：最后淘汰周序列中的最后一周（决赛周）
        if k == 0 and i == len(vote_weeks) - 1:
            champ_rank = g_scored.loc[g_scored["overall_rank_rankmethod"] == 1, "contestant"].iloc[0]
            champ_pct = g_scored.loc[g_scored["overall_rank_percent"] == 1, "contestant"].iloc[0]
            champ_info = {
                "season": season,
                "final_vote_week": w,
                "champion_rank_method": champ_rank,
                "champion_percent_method": champ_pct
            }

    weekly = pd.DataFrame(weekly_rows)
    detail = pd.concat(detail_rows, ignore_index=True)

    # 冲突周精细明细（方便你写解释）
    conflict_weeks = weekly.loc[weekly["conflict"]].copy()
    long_rows = []
    if not conflict_weeks.empty:
        for _, row in conflict_weeks.iterrows():
            s = int(row["season"]); w = int(row["week"])
            week_detail = detail[(detail["season"] == s) & (detail["week"] == w)].copy()

            elim_rank_names = [x.strip() for x in str(row["eliminated_by_rank"]).split(",")] if row["eliminated_by_rank"] != "-" else []
            for name in elim_rank_names:
                r = week_detail[week_detail["contestant"] == name]
                if r.empty:
                    continue
                r = r.iloc[0]
                long_rows.append({
                    "season": s, "week": w, "method": "rank",
                    "eliminated": name,
                    "judge_total": r["judge_total"],
                    "estimated_votes_total": r["estimated_votes_total"],
                    "judge_rank": r["judge_rank"],
                    "fan_rank": r["fan_rank"],
                    "sum_ranks": r["sum_ranks"]
                })

            elim_pct_names = [x.strip() for x in str(row["eliminated_by_percent"]).split(",")] if row["eliminated_by_percent"] != "-" else []
            for name in elim_pct_names:
                r = week_detail[week_detail["contestant"] == name]
                if r.empty:
                    continue
                r = r.iloc[0]
                long_rows.append({
                    "season": s, "week": w, "method": "percent",
                    "eliminated": name,
                    "judge_total": r["judge_total"],
                    "estimated_votes_total": r["estimated_votes_total"],
                    "judge_percent": r.get("judge_percent", np.nan),
                    "fan_percent": r.get("fan_percent", np.nan),
                    "combined_percent": r.get("combined_percent", np.nan)
                })

    conflict_detail = pd.DataFrame(long_rows) if long_rows else pd.DataFrame()
    return weekly, detail, conflict_detail, champ_info


# =========================
# 5) 主程序：跑全部赛季 + 输出冲突赛季周
# =========================
def main():
    if not os.path.exists(VOTES_PATH):
        raise FileNotFoundError(f"找不到推断票文件：{VOTES_PATH}")

    votes_raw = pd.read_csv(VOTES_PATH)
    votes = resolve_columns(votes_raw)

    # 真实冠军（可选）
    real_champs = {}
    if os.path.exists(OFFICIAL_PATH):
        try:
            official = pd.read_csv(OFFICIAL_PATH)
            if {"season", "placement", "celebrity_name"}.issubset(set(official.columns.astype(str))):
                tmp = official.loc[official["placement"] == 1, ["season", "celebrity_name"]].dropna()
                real_champs = dict(zip(tmp["season"].astype(int), tmp["celebrity_name"].astype(str)))
        except Exception:
            pass

    seasons = sorted(votes["season"].unique().tolist())
    print(f"✅ 检测到赛季数：{len(seasons)}，范围：{seasons[0]} ~ {seasons[-1]}")

    weekly_all, detail_all = [], []
    conflict_detail_all = []
    champs_all = []
    skipped = []

    for s in seasons:
        weekly, detail, conflict_detail, champ_info = simulate_season(votes, s)
        if weekly is None:
            skipped.append(s)
            continue
        weekly_all.append(weekly)
        detail_all.append(detail)
        if conflict_detail is not None and not conflict_detail.empty:
            conflict_detail_all.append(conflict_detail)
        if champ_info is not None:
            champ_info["real_champion_official"] = real_champs.get(s, np.nan)
            champ_info["champion_match_rank"] = (champ_info["champion_rank_method"] == champ_info["real_champion_official"]) if real_champs else np.nan
            champ_info["champion_match_percent"] = (champ_info["champion_percent_method"] == champ_info["real_champion_official"]) if real_champs else np.nan
            champs_all.append(champ_info)

    if len(weekly_all) == 0:
        raise RuntimeError("没有任何赛季成功模拟：可能每个赛季的投票周不足，或票数列全缺失。")

    weekly_all = pd.concat(weekly_all, ignore_index=True).sort_values(["season", "week"])
    detail_all = pd.concat(detail_all, ignore_index=True).sort_values(["season", "week", "overall_rank_rankmethod"])
    champs_df = pd.DataFrame(champs_all).sort_values("season") if champs_all else pd.DataFrame()
    conflict_detail_all = (
        pd.concat(conflict_detail_all, ignore_index=True).sort_values(["season", "week", "method"])
        if len(conflict_detail_all) > 0 else pd.DataFrame()
    )

    # ✅输出“冲突的赛季-周”
    conflict_weeks = weekly_all[(weekly_all["k_elims_inferred"] > 0) & (weekly_all["conflict"])].copy()
    conflict_weeks = conflict_weeks.sort_values(["season", "week"])
    conflict_weeks.to_csv(OUT_CONFLICT_CSV, index=False, encoding="utf-8-sig")

    # Excel 多 sheet
    with pd.ExcelWriter(OUT_EXCEL, engine="openpyxl") as writer:
        weekly_all.to_excel(writer, index=False, sheet_name="Weekly_All")
        conflict_weeks.to_excel(writer, index=False, sheet_name="Conflicts_Weeks")
        if not conflict_detail_all.empty:
            conflict_detail_all.to_excel(writer, index=False, sheet_name="Conflicts_Detail")
        if not champs_df.empty:
            champs_df.to_excel(writer, index=False, sheet_name="Champions")
        detail_all.to_excel(writer, index=False, sheet_name="Detail_All")

    # 控制台摘要
    n_conflicts = int(conflict_weeks.shape[0])
    n_elim_weeks = int(weekly_all[weekly_all["k_elims_inferred"] > 0].shape[0])

    print(f"\n✅ 已输出 Excel：{OUT_EXCEL}")
    print(f"✅ 已输出冲突周 CSV：{OUT_CONFLICT_CSV}")
    print("\n=== Summary ===")
    print(f"成功模拟赛季数：{len(seasons) - len(skipped)}（跳过：{len(skipped)}）")
    if skipped:
        print(f"跳过赛季（投票周不足）：{skipped}")
    print(f"总淘汰周数（有淘汰）：{n_elim_weeks}")
    print(f"冲突周数（两方法淘汰不同）：{n_conflicts}")
    if n_conflicts > 0:
        print("\n=== First 30 conflict weeks ===")
        print(conflict_weeks.head(30).to_string(index=False))


if __name__ == "__main__":
    main()
