import pandas as pd
import numpy as np

# =========================
# 0) 文件路径（按你的实际位置改）
# =========================
FIRST_TABLE_PATH = "dwts_inferred_fan_votes - 第二问·.csv"   # 你的“第一个表格”
OUT_XLSX = "dwts_filled_elims.xlsx"
OUT_CSV  = "dwts_filled_elims.csv"

# =========================
# 1) 读取 + 清理
# =========================
df = pd.read_csv(FIRST_TABLE_PATH)

# 去掉 Unnamed 空列（如果有）
df = df.loc[:, ~df.columns.str.contains(r"^Unnamed")].copy()

need_cols = ["season", "week", "contestant", "judge_total", "estimated_votes_total"]
missing = [c for c in need_cols if c not in df.columns]
if missing:
    raise ValueError(f"缺少必要列：{missing}，请检查CSV列名。")

df["season"] = pd.to_numeric(df["season"], errors="coerce").astype("Int64")
df["week"] = pd.to_numeric(df["week"], errors="coerce").astype("Int64")
df["judge_total"] = pd.to_numeric(df["judge_total"], errors="coerce")
df["estimated_votes_total"] = pd.to_numeric(df["estimated_votes_total"], errors="coerce")

df = df.dropna(subset=need_cols).copy()

# =========================
# 2) 两种方法：每周淘汰者（与2.1.py一致的逻辑）
# =========================
def pick_elim_by_rank(g: pd.DataFrame) -> str:
    """
    Rank 法：
    judge_total 和 estimated_votes_total 各自按降序排名（高者=1）
    sum_ranks 最大者（最差）淘汰。
    tie-break：fan_rank 更差 -> judge_rank 更差 -> contestant 字母序
    """
    gg = g.copy()
    gg["judge_rank"] = gg["judge_total"].rank(ascending=False, method="min")
    gg["fan_rank"]   = gg["estimated_votes_total"].rank(ascending=False, method="min")
    gg["sum_ranks"]  = gg["judge_rank"] + gg["fan_rank"]

    gg = gg.sort_values(
        by=["sum_ranks", "fan_rank", "judge_rank", "contestant"],
        ascending=[False, False, False, True]
    )
    return str(gg.iloc[0]["contestant"])


def pick_elim_by_percent(g: pd.DataFrame) -> str:
    """
    Percent 法：
    judge_percent = judge_total / sum_judge
    fan_percent   = votes / sum_votes
    combined = judge_percent + fan_percent
    combined 最小者淘汰。
    tie-break：fan_percent 更小 -> judge_percent 更小 -> contestant 字母序
    """
    gg = g.copy()
    sum_j = gg["judge_total"].sum()
    sum_v = gg["estimated_votes_total"].sum()

    # 兜底：防止除0/异常
    if (sum_j <= 0) or (sum_v <= 0):
        gg = gg.sort_values(["estimated_votes_total", "judge_total", "contestant"],
                            ascending=[True, True, True])
        return str(gg.iloc[0]["contestant"])

    gg["judge_percent"] = gg["judge_total"] / sum_j
    gg["fan_percent"]   = gg["estimated_votes_total"] / sum_v
    gg["combined_percent"] = gg["judge_percent"] + gg["fan_percent"]

    gg = gg.sort_values(
        by=["combined_percent", "fan_percent", "judge_percent", "contestant"],
        ascending=[True, True, True, True]
    )
    return str(gg.iloc[0]["contestant"])


# =========================
# 3) 生成“按周汇总表”：每个 season-week 两种方法各淘汰谁
# =========================
weekly = (
    df.groupby(["season", "week"], sort=True)
      .apply(lambda g: pd.Series({
          "elim_by_rank": pick_elim_by_rank(g),
          "elim_by_percent": pick_elim_by_percent(g),
          "n_contestants": g["contestant"].nunique()
      }))
      .reset_index()
)

# 可选：加一个标记列，表示两种方法是否一致
weekly["same_elim?"] = (weekly["elim_by_rank"] == weekly["elim_by_percent"])

# =========================
# 4) 回填到“第一个表格”(行级表)：给每行加上该周的淘汰者信息
# =========================
df_filled = df.merge(weekly[["season", "week", "elim_by_rank", "elim_by_percent", "same_elim?"]],
                     on=["season", "week"], how="left")

# =========================
# 5) 输出（Excel里放两张表：行级表 + 按周汇总表）
# =========================
with pd.ExcelWriter(OUT_XLSX, engine="openpyxl") as writer:
    df_filled.to_excel(writer, index=False, sheet_name="Row_Level_Filled")
    weekly.to_excel(writer, index=False, sheet_name="Weekly_Elims")

df_filled.to_csv(OUT_CSV, index=False, encoding="utf-8-sig")

print("✅ 已生成：")
print(" -", OUT_XLSX, "(含 Row_Level_Filled 与 Weekly_Elims 两个sheet)")
print(" -", OUT_CSV)
print("按周汇总表预览：")
print(weekly.head(10))
